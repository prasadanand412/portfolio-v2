var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../node_modules/unenv/dist/runtime/_internal/utils.mjs
// @__NO_SIDE_EFFECTS__
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw /* @__PURE__ */ createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// ../node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  static {
    __name(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark = class PerformanceMark2 extends PerformanceEntry {
  static {
    __name(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance = class {
  static {
    __name(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e4) => e4.name !== markName) : this._entries.filter((e4) => e4.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e4) => e4.name !== measureName) : this._entries.filter((e4) => e4.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e4) => e4.entryType !== "resource" || e4.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e4) => e4.name === name && (!type || e4.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e4) => e4.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver = class {
  static {
    __name(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
if (!("__unenv__" in performance)) {
  const proto = Performance.prototype;
  for (const key of Object.getOwnPropertyNames(proto)) {
    if (key !== "constructor" && !(key in performance)) {
      const desc = Object.getOwnPropertyDescriptor(proto, key);
      if (desc) {
        Object.defineProperty(performance, key, desc);
      }
    }
  }
}
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// ../node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// ../node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// ../node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// ../node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// ../node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// ../node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// ../node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
var ReadStream = class {
  static {
    __name(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};

// ../node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
var WriteStream = class {
  static {
    __name(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir3, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x2, y2, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env2) {
    return 1;
  }
  hasColors(count3, env2) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};

// ../node_modules/unenv/dist/runtime/node/internal/process/node-version.mjs
var NODE_VERSION = "22.14.0";

// ../node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class _Process extends EventEmitter {
  static {
    __name(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd2) {
    this.#cwd = cwd2;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION}`;
  }
  get versions() {
    return { node: NODE_VERSION };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var workerdProcess = getBuiltinModule("node:process");
var unenvProcess = new Process({
  env: globalProcess.env,
  hrtime,
  // `nextTick` is available from workerd process v1
  nextTick: workerdProcess.nextTick
});
var { exit, features, platform } = workerdProcess;
var {
  _channel,
  _debugEnd,
  _debugProcess,
  _disconnect,
  _events,
  _eventsCount,
  _exiting,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _handleQueue,
  _kill,
  _linkedBinding,
  _maxListeners,
  _pendingMessage,
  _preload_modules,
  _rawDebug,
  _send,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  arch,
  argv,
  argv0,
  assert: assert2,
  availableMemory,
  binding,
  channel,
  chdir,
  config,
  connected,
  constrainedMemory,
  cpuUsage,
  cwd,
  debugPort,
  disconnect,
  dlopen,
  domain,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exitCode,
  finalization,
  getActiveResourcesInfo,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getMaxListeners,
  getuid,
  hasUncaughtExceptionCaptureCallback,
  hrtime: hrtime3,
  initgroups,
  kill,
  listenerCount,
  listeners,
  loadEnvFile,
  mainModule,
  memoryUsage,
  moduleLoadList,
  nextTick,
  off,
  on,
  once,
  openStdin,
  permission,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  reallyExit,
  ref,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  send,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setMaxListeners,
  setSourceMapsEnabled,
  setuid,
  setUncaughtExceptionCaptureCallback,
  sourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  throwDeprecation,
  title,
  traceDeprecation,
  umask,
  unref,
  uptime,
  version,
  versions
} = unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// ../node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// _worker.js
var e = /* @__PURE__ */ __name((e4, t3, n2) => (r2, i2) => {
  let a2 = -1;
  return o2(0);
  async function o2(s2) {
    if (s2 <= a2) throw Error(`next() called multiple times`);
    a2 = s2;
    let c2, l2 = false, u2;
    if (e4[s2] ? (u2 = e4[s2][0][0], r2.req.routeIndex = s2) : u2 = s2 === e4.length && i2 || void 0, u2) try {
      c2 = await u2(r2, () => o2(s2 + 1));
    } catch (e5) {
      if (e5 instanceof Error && t3) r2.error = e5, c2 = await t3(e5, r2), l2 = true;
      else throw e5;
    }
    else r2.finalized === false && n2 && (c2 = await n2(r2));
    return c2 && (r2.finalized === false || l2) && (r2.res = c2), r2;
  }
  __name(o2, "o");
}, "e");
var t = /* @__PURE__ */ Symbol();
var n = /* @__PURE__ */ __name((e4, t3) => new Response(e4, { headers: { "Content-Type": t3.replace(/^[^;]+/, (e5) => e5.toLowerCase()) } }).formData(), "n");
var r = 32;
var i = 1e4;
var a = /* @__PURE__ */ __name((e4) => `headers` in e4, "a");
var o = /* @__PURE__ */ __name(async (e4, t3 = /* @__PURE__ */ Object.create(null)) => {
  let { all: n2 = false, dot: r2 = false } = t3, i2 = (a(e4) ? e4.headers : e4.raw.headers).get(`Content-Type`)?.split(`;`)[0].trim().toLowerCase();
  return i2 === `multipart/form-data` || i2 === `application/x-www-form-urlencoded` ? s(e4, { all: n2, dot: r2 }) : {};
}, "o");
async function s(e4, t3) {
  if (!a(e4) && e4.bodyCache.formData) return c(await e4.bodyCache.formData, t3);
  let r2 = a(e4) ? e4.headers : e4.raw.headers, i2 = n(await e4.arrayBuffer(), r2.get(`Content-Type`) || ``);
  a(e4) || (e4.bodyCache.formData = i2);
  let o2 = await i2;
  return o2 ? c(o2, t3) : {};
}
__name(s, "s");
function c(e4, t3) {
  let n2 = /* @__PURE__ */ Object.create(null), r2 = { count: 0 };
  return e4.forEach((e5, r3) => {
    t3.all || r3.endsWith(`[]`) ? l(n2, r3, e5) : n2[r3] = e5;
  }), t3.dot && Object.entries(n2).forEach(([e5, t4]) => {
    e5.includes(`.`) && (u(n2, e5, t4, r2), delete n2[e5]);
  }), n2;
}
__name(c, "c");
var l = /* @__PURE__ */ __name((e4, t3, n2) => {
  e4[t3] === void 0 ? e4[t3] = t3.endsWith(`[]`) ? [n2] : n2 : Array.isArray(e4[t3]) ? e4[t3].push(n2) : e4[t3] = [e4[t3], n2];
}, "l");
var u = /* @__PURE__ */ __name((e4, t3, n2, a2) => {
  if (/(?:^|\.)__proto__\./.test(t3)) return;
  let o2 = e4, s2 = t3.split(`.`, r + 2);
  s2.length > r + 1 && d(), s2.forEach((e5, t4) => {
    t4 === s2.length - 1 ? o2[e5] = n2 : ((!o2[e5] || typeof o2[e5] != `object` || Array.isArray(o2[e5]) || o2[e5] instanceof File) && (a2.count++ >= i && d(), o2[e5] = /* @__PURE__ */ Object.create(null)), o2 = o2[e5]);
  });
}, "u");
var d = /* @__PURE__ */ __name(() => {
  throw Error(`Nesting limit exceeded`);
}, "d");
var f = /* @__PURE__ */ __name((e4) => {
  let t3 = e4.split(`/`);
  return t3[0] === `` && t3.shift(), t3;
}, "f");
var p = /* @__PURE__ */ __name((e4) => {
  let { groups: t3, path: n2 } = m(e4);
  return h(f(n2), t3);
}, "p");
var m = /* @__PURE__ */ __name((e4) => {
  let t3 = [];
  return e4 = e4.replace(/\{[^}]+\}/g, (e5, n2) => {
    let r2 = `@${n2}`;
    return t3.push([r2, e5]), r2;
  }), { groups: t3, path: e4 };
}, "m");
var h = /* @__PURE__ */ __name((e4, t3) => {
  for (let n2 = t3.length - 1; n2 >= 0; n2--) {
    let [r2] = t3[n2];
    for (let i2 = e4.length - 1; i2 >= 0; i2--) if (e4[i2].includes(r2)) {
      e4[i2] = e4[i2].replace(r2, t3[n2][1]);
      break;
    }
  }
  return e4;
}, "h");
var g = {};
var _ = /* @__PURE__ */ __name((e4, t3) => {
  if (e4 === `*`) return `*`;
  let n2 = e4.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (n2) {
    let r2 = `${e4}#${t3}`;
    return g[r2] || (g[r2] = n2[2] ? t3 && t3[0] !== `:` && t3[0] !== `*` ? [r2, n2[1], RegExp(`^${n2[2]}(?=/${t3})`)] : [e4, n2[1], RegExp(`^${n2[2]}$`)] : [e4, n2[1], true]), g[r2];
  }
  return null;
}, "_");
var v = /* @__PURE__ */ __name((e4, t3) => {
  try {
    return t3(e4);
  } catch {
    return e4.replace(/(?:%[0-9A-Fa-f]{2})+/g, (e5) => {
      try {
        return t3(e5);
      } catch {
        return e5;
      }
    });
  }
}, "v");
var y = /* @__PURE__ */ __name((e4) => v(e4, decodeURI), "y");
var b = /* @__PURE__ */ __name((e4) => {
  let t3 = e4.url, n2 = t3.indexOf(`/`, t3.indexOf(`:`) + 4), r2 = n2;
  for (; r2 < t3.length; r2++) {
    let e5 = t3.charCodeAt(r2);
    if (e5 === 37) {
      let e6 = t3.indexOf(`?`, r2), i2 = t3.indexOf(`#`, r2), a2 = e6 === -1 ? i2 === -1 ? void 0 : i2 : i2 === -1 ? e6 : Math.min(e6, i2), o2 = t3.slice(n2, a2);
      return y(o2.includes(`%25`) ? o2.replace(/%25/g, `%2525`) : o2);
    }
    if (e5 === 63 || e5 === 35) break;
  }
  return t3.slice(n2, r2);
}, "b");
var ee = /* @__PURE__ */ __name((e4) => {
  let t3 = b(e4);
  return t3.length > 1 && t3.at(-1) === `/` ? t3.slice(0, -1) : t3;
}, "ee");
var x = /* @__PURE__ */ __name((e4, t3, ...n2) => (n2.length && (t3 = x(t3, ...n2)), `${e4?.[0] === `/` ? `` : `/`}${e4}${t3 === `/` ? `` : `${e4?.at(-1) === `/` ? `` : `/`}${t3?.[0] === `/` ? t3.slice(1) : t3}`}`), "x");
var S = /* @__PURE__ */ __name((e4) => {
  if (e4.charCodeAt(e4.length - 1) !== 63 || !e4.includes(`:`)) return null;
  let t3 = e4.split(`/`), n2 = [], r2 = ``;
  return t3.forEach((e5) => {
    if (e5 !== `` && !/\:/.test(e5)) r2 += `/` + e5;
    else if (/\:/.test(e5)) {
      if (e5.charCodeAt(e5.length - 1) === 63) {
        n2.length === 0 && r2 === `` ? n2.push(`/`) : n2.push(r2);
        let t4 = e5.slice(0, -1);
        r2 += `/` + t4, n2.push(r2);
      } else r2 += `/` + e5;
    }
  }), n2.filter((e5, t4, n3) => n3.indexOf(e5) === t4);
}, "S");
var C = /* @__PURE__ */ __name((e4) => e4.indexOf(`%`) === -1 ? e4 : v(e4, ne), "C");
var w = /* @__PURE__ */ __name((e4) => (e4.indexOf(`+`) !== -1 && (e4 = e4.replace(/\+/g, ` `)), C(e4)), "w");
var T = /* @__PURE__ */ __name((e4, t3, n2) => {
  let r2 = e4.indexOf(`#`, 8);
  r2 !== -1 && (e4 = e4.slice(0, r2));
  let i2;
  if (!n2 && t3 && t3.indexOf(`%`) === -1 && t3.indexOf(`+`) === -1) {
    let n3 = e4.indexOf(`?`, 8);
    if (n3 === -1) return;
    for (e4.startsWith(t3, n3 + 1) || (n3 = e4.indexOf(`&${t3}`, n3 + 1)); n3 !== -1; ) {
      let r3 = e4.charCodeAt(n3 + t3.length + 1);
      if (r3 === 61) {
        let r4 = n3 + t3.length + 2, i3 = e4.indexOf(`&`, r4);
        return w(e4.slice(r4, i3 === -1 ? void 0 : i3));
      }
      if (r3 == 38 || isNaN(r3)) return ``;
      n3 = e4.indexOf(`&${t3}`, n3 + 1);
    }
    if (i2 = /[%+]/.test(e4), !i2) return;
  }
  let a2 = /* @__PURE__ */ Object.create(null);
  i2 ??= /[%+]/.test(e4);
  let o2 = e4.indexOf(`?`, 8);
  for (; o2 !== -1; ) {
    let t4 = e4.indexOf(`&`, o2 + 1), r3 = e4.indexOf(`=`, o2);
    r3 > t4 && t4 !== -1 && (r3 = -1);
    let s2 = e4.slice(o2 + 1, r3 === -1 ? t4 === -1 ? void 0 : t4 : r3);
    if (i2 && (s2 = w(s2)), o2 = t4, s2 === ``) continue;
    let c2;
    r3 === -1 ? c2 = `` : (c2 = e4.slice(r3 + 1, t4 === -1 ? void 0 : t4), i2 && (c2 = w(c2))), n2 ? (a2[s2] && Array.isArray(a2[s2]) || (a2[s2] = []), a2[s2].push(c2)) : a2[s2] ??= c2;
  }
  return t3 ? a2[t3] : a2;
}, "T");
var E = T;
var te = /* @__PURE__ */ __name((e4, t3) => T(e4, t3, true), "te");
var ne = decodeURIComponent;
var re = class {
  static {
    __name(this, "re");
  }
  raw;
  #e;
  #t;
  routeIndex = 0;
  path;
  bodyCache = {};
  constructor(e4, t3 = `/`, n2 = [[]]) {
    this.raw = e4, this.path = t3, this.#t = n2;
  }
  param(e4) {
    return e4 ? this.#n(e4) : this.#r();
  }
  #n(e4) {
    let t3 = this.#t[0][this.routeIndex]?.[1][e4], n2 = this.#i(t3);
    return n2 && C(n2);
  }
  #r() {
    let e4 = {}, t3 = Object.keys(this.#t[0][this.routeIndex]?.[1] ?? {});
    for (let n2 of t3) {
      let t4 = this.#i(this.#t[0][this.routeIndex][1][n2]);
      t4 !== void 0 && (e4[n2] = C(t4));
    }
    return e4;
  }
  #i(e4) {
    return this.#t[1] ? this.#t[1][e4] : e4;
  }
  query(e4) {
    return E(this.url, e4);
  }
  queries(e4) {
    return te(this.url, e4);
  }
  header(e4) {
    if (e4) return this.raw.headers.get(e4) ?? void 0;
    let t3 = /* @__PURE__ */ Object.create(null);
    return this.raw.headers.forEach((e5, n2) => {
      t3[n2] = e5;
    }), t3;
  }
  async parseBody(e4) {
    return o(this, e4);
  }
  #a = /* @__PURE__ */ __name((e4) => {
    let { bodyCache: t3, raw: n2 } = this, r2 = t3[e4];
    if (r2) return r2;
    for (let n3 in t3) return t3[n3].then((t4) => (n3 === `json` && (t4 = JSON.stringify(t4)), new Response(t4)[e4]()));
    return t3[e4] = n2[e4]();
  }, "#a");
  json() {
    return this.#a(`text`).then((e4) => JSON.parse(e4));
  }
  text() {
    return this.#a(`text`);
  }
  arrayBuffer() {
    return this.#a(`arrayBuffer`);
  }
  bytes() {
    return this.#a(`arrayBuffer`).then((e4) => new Uint8Array(e4));
  }
  blob() {
    return this.#a(`blob`);
  }
  formData() {
    return this.#a(`formData`);
  }
  addValidatedData(e4, t3) {
    (this.#e ??= {})[e4] = t3;
  }
  valid(e4) {
    return this.#e?.[e4];
  }
  get url() {
    return this.raw.url;
  }
  get method() {
    return this.raw.method;
  }
  get [t]() {
    return this.#t;
  }
  get matchedRoutes() {
    return this.#t[0].map(([[, e4]]) => e4);
  }
  get routePath() {
    return this.#t[0].map(([[, e4]]) => e4)[this.routeIndex].path;
  }
};
var ie = { Stringify: 1, BeforeStream: 2, Stream: 3 };
var ae = /* @__PURE__ */ __name((e4, t3) => {
  let n2 = new String(e4);
  return n2.isEscaped = true, n2.callbacks = t3, n2;
}, "ae");
var D = /* @__PURE__ */ __name(async (e4, t3, n2, r2, i2) => {
  typeof e4 == `object` && !(e4 instanceof String) && (e4 instanceof Promise || (e4 = e4.toString()), e4 instanceof Promise && (e4 = await e4));
  let a2 = e4.callbacks;
  if (!a2?.length) return Promise.resolve(e4);
  i2 ? i2[0] += e4 : i2 = [e4];
  let o2 = Promise.all(a2.map((e5) => e5({ phase: t3, buffer: i2, context: r2 }))).then((e5) => Promise.all(e5.filter(Boolean).map((e6) => D(e6, t3, false, r2, i2))).then(() => i2[0]));
  return n2 ? ae(await o2, a2) : o2;
}, "D");
var O = `text/plain; charset=UTF-8`;
var k = /* @__PURE__ */ __name((e4, t3) => ({ "Content-Type": e4, ...t3 }), "k");
var A = /* @__PURE__ */ __name((e4, t3) => new Response(e4, t3), "A");
var oe = class {
  static {
    __name(this, "oe");
  }
  #e;
  #t;
  env = {};
  #n;
  finalized = false;
  error;
  #r;
  #i;
  #a;
  #o;
  #s;
  #c;
  #l;
  #u;
  #d;
  constructor(e4, t3) {
    this.#e = e4, t3 && (this.#i = t3.executionCtx, this.env = t3.env, this.#c = t3.notFoundHandler, this.#d = t3.path, this.#u = t3.matchResult);
  }
  get req() {
    return this.#t ??= new re(this.#e, this.#d, this.#u), this.#t;
  }
  get event() {
    if (this.#i && `respondWith` in this.#i) return this.#i;
    throw Error(`This context has no FetchEvent`);
  }
  get executionCtx() {
    if (this.#i) return this.#i;
    throw Error(`This context has no ExecutionContext`);
  }
  get res() {
    return this.#a ||= A(null, { headers: this.#l ??= new Headers() });
  }
  set res(e4) {
    if (this.#a && e4) {
      e4 = A(e4.body, e4);
      for (let [t3, n2] of this.#a.headers.entries()) if (t3 !== `content-type`) {
        if (t3 === `set-cookie`) {
          let t4 = this.#a.headers.getSetCookie();
          e4.headers.delete(`set-cookie`);
          for (let n3 of t4) e4.headers.append(`set-cookie`, n3);
        } else e4.headers.set(t3, n2);
      }
    }
    this.#a = e4, this.finalized = true;
  }
  render = /* @__PURE__ */ __name((...e4) => (this.#s ??= (e5) => this.html(e5), this.#s(...e4)), "render");
  setLayout = /* @__PURE__ */ __name((e4) => this.#o = e4, "setLayout");
  getLayout = /* @__PURE__ */ __name(() => this.#o, "getLayout");
  setRenderer = /* @__PURE__ */ __name((e4) => {
    this.#s = e4;
  }, "setRenderer");
  header = /* @__PURE__ */ __name((e4, t3, n2) => {
    this.finalized && (this.#a = A(this.#a.body, this.#a));
    let r2 = this.#a ? this.#a.headers : this.#l ??= new Headers();
    t3 === void 0 ? r2.delete(e4) : n2?.append ? r2.append(e4, t3) : r2.set(e4, t3);
  }, "header");
  status = /* @__PURE__ */ __name((e4) => {
    this.#r = e4;
  }, "status");
  set = /* @__PURE__ */ __name((e4, t3) => {
    this.#n ??= /* @__PURE__ */ new Map(), this.#n.set(e4, t3);
  }, "set");
  get = /* @__PURE__ */ __name((e4) => this.#n ? this.#n.get(e4) : void 0, "get");
  get var() {
    return this.#n ? Object.fromEntries(this.#n) : {};
  }
  #f(e4, t3, n2) {
    let r2 = this.#a ? new Headers(this.#a.headers) : this.#l;
    if (typeof t3 == `object` && t3.headers) {
      r2 ??= new Headers();
      for (let [e5, n3] of new Headers(t3.headers)) e5 === `set-cookie` ? r2.append(e5, n3) : r2.set(e5, n3);
    }
    if (n2) {
      if (!r2) {
        let e5 = 0;
        for (let t4 in n2) if (++e5 > 1 || typeof n2[t4] != `string`) {
          r2 = new Headers();
          break;
        }
      }
      if (r2) for (let e5 in n2) {
        let t4 = n2[e5];
        if (typeof t4 == `string`) r2.set(e5, t4);
        else {
          r2.delete(e5);
          for (let n3 of t4) r2.append(e5, n3);
        }
      }
    }
    return A(e4, { status: typeof t3 == `number` ? t3 : t3?.status ?? this.#r, headers: r2 ?? n2 });
  }
  newResponse = /* @__PURE__ */ __name((...e4) => this.#f(...e4), "newResponse");
  body = /* @__PURE__ */ __name((e4, t3, n2) => this.#f(e4, t3, n2), "body");
  text = /* @__PURE__ */ __name((e4, t3, n2) => !this.#l && !this.#r && !t3 && !n2 && !this.finalized ? new Response(e4) : this.#f(e4, t3, k(O, n2)), "text");
  json = /* @__PURE__ */ __name((e4, t3, n2) => this.#f(JSON.stringify(e4), t3, k(`application/json`, n2)), "json");
  html = /* @__PURE__ */ __name((e4, t3, n2) => {
    let r2 = /* @__PURE__ */ __name((e5) => this.#f(e5, t3, k(`text/html; charset=UTF-8`, n2)), "r");
    return typeof e4 == `object` ? D(e4, ie.Stringify, false, {}).then(r2) : r2(e4);
  }, "html");
  redirect = /* @__PURE__ */ __name((e4, t3) => {
    let n2 = String(e4);
    return this.header(`Location`, /[^\x00-\xFF]/.test(n2) ? encodeURI(n2) : n2), this.newResponse(null, t3 ?? 302);
  }, "redirect");
  notFound = /* @__PURE__ */ __name(() => (this.#c ??= () => A(), this.#c(this)), "notFound");
};
var se = [`get`, `post`, `put`, `delete`, `options`, `patch`, `query`];
var j = `Can not add a route since the matcher is already built.`;
var M = class extends Error {
  static {
    __name(this, "M");
  }
};
var ce = `__COMPOSED_HANDLER`;
var le = /* @__PURE__ */ __name((e4) => e4.text(`404 Not Found`, 404), "le");
var N = /* @__PURE__ */ __name((e4, t3) => {
  if (`getResponse` in e4) {
    let n2 = e4.getResponse();
    return t3.newResponse(n2.body, n2);
  }
  return console.error(e4), t3.text(`Internal Server Error`, 500);
}, "N");
var ue = class t2 {
  static {
    __name(this, "t");
  }
  get;
  post;
  put;
  delete;
  options;
  patch;
  query;
  all;
  on;
  use;
  router;
  getPath;
  _basePath = `/`;
  #e = `/`;
  routes = [];
  constructor(e4 = {}) {
    [...se, `all`].forEach((e5) => {
      this[e5] = (t4, ...n3) => (typeof t4 == `string` ? this.#e = t4 : this.#r(e5, this.#e, t4), n3.forEach((t5) => {
        this.#r(e5, this.#e, t5);
      }), this);
    }), this.on = (e5, t4, ...n3) => {
      for (let r2 of [t4].flat()) {
        this.#e = r2;
        for (let t5 of [e5].flat()) n3.map((e6) => {
          this.#r(t5.toUpperCase(), this.#e, e6);
        });
      }
      return this;
    }, this.use = (e5, ...t4) => (typeof e5 == `string` ? this.#e = e5 : (this.#e = `*`, t4.unshift(e5)), t4.forEach((e6) => {
      this.#r(`ALL`, this.#e, e6);
    }), this);
    let { strict: t3, ...n2 } = e4;
    Object.assign(this, n2), this.getPath = t3 ?? true ? e4.getPath ?? b : ee;
  }
  #t() {
    let e4 = new t2({ router: this.router, getPath: this.getPath });
    return e4.errorHandler = this.errorHandler, e4.#n = this.#n, e4.routes = this.routes, e4;
  }
  #n = le;
  errorHandler = N;
  route(t3, n2) {
    let r2 = this.basePath(t3);
    return n2.routes.map((t4) => {
      let i2;
      n2.errorHandler === N ? i2 = t4.handler : (i2 = /* @__PURE__ */ __name(async (r3, i3) => (await e([], n2.errorHandler)(r3, () => t4.handler(r3, i3))).res, "i"), i2[ce] = t4.handler), r2.#r(t4.method, t4.path, i2, t4.basePath);
    }), this;
  }
  basePath(e4) {
    let t3 = this.#t();
    return t3._basePath = x(this._basePath, e4), t3;
  }
  onError = /* @__PURE__ */ __name((e4) => (this.errorHandler = e4, this), "onError");
  notFound = /* @__PURE__ */ __name((e4) => (this.#n = e4, this), "notFound");
  mount(e4, t3, n2) {
    let r2, i2;
    n2 && (typeof n2 == `function` ? i2 = n2 : (i2 = n2.optionHandler, r2 = n2.replaceRequest === false ? (e5) => e5 : n2.replaceRequest));
    let a2 = i2 ? (e5) => {
      let t4 = i2(e5);
      return Array.isArray(t4) ? t4 : [t4];
    } : (e5) => {
      let t4;
      try {
        t4 = e5.executionCtx;
      } catch {
      }
      return [e5.env, t4];
    };
    return r2 ||= (() => {
      let t4 = x(this._basePath, e4), n3 = t4 === `/` ? 0 : t4.length;
      return (e5) => {
        let t5 = new URL(e5.url);
        return t5.pathname = this.getPath(e5).slice(n3) || `/`, new Request(t5, e5);
      };
    })(), this.#r(`ALL`, x(e4, `*`), async (e5, n3) => {
      let i3 = await t3(r2(e5.req.raw), ...a2(e5));
      if (i3) return i3;
      await n3();
    }), this;
  }
  #r(e4, t3, n2, r2) {
    e4 = e4.toUpperCase(), t3 = x(this._basePath, t3);
    let i2 = { basePath: r2 === void 0 ? this._basePath : x(this._basePath, r2), path: t3, method: e4, handler: n2 };
    this.router.add(e4, t3, [n2, i2]), this.routes.push(i2);
  }
  #i(e4, t3) {
    if (e4 instanceof Error) return this.errorHandler(e4, t3);
    throw e4;
  }
  #a(t3, n2, r2, i2) {
    if (i2 === `HEAD`) return (async () => new Response(null, await this.#a(t3, n2, r2, `GET`)))();
    let a2 = this.getPath(t3, { env: r2 }), o2 = this.router.match(i2, a2), s2 = new oe(t3, { path: a2, matchResult: o2, env: r2, executionCtx: n2, notFoundHandler: this.#n });
    if (o2[0].length === 1) {
      let e4;
      try {
        e4 = o2[0][0][0][0](s2, async () => {
          s2.res = await this.#n(s2);
        });
      } catch (e5) {
        return this.#i(e5, s2);
      }
      return e4 instanceof Promise ? e4.then((e5) => e5 || (s2.finalized ? s2.res : this.#n(s2))).catch((e5) => this.#i(e5, s2)) : e4 ?? this.#n(s2);
    }
    let c2 = e(o2[0], this.errorHandler, this.#n);
    return (async () => {
      try {
        let e4 = await c2(s2);
        if (!e4.finalized) throw Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
        return e4.res;
      } catch (e4) {
        return this.#i(e4, s2);
      }
    })();
  }
  fetch = /* @__PURE__ */ __name((e4, ...t3) => this.#a(e4, t3[1], t3[0], e4.method), "fetch");
  request = /* @__PURE__ */ __name((e4, t3, n2, r2) => e4 instanceof Request ? this.fetch(t3 ? new Request(e4, t3) : e4, n2, r2) : (e4 = e4.toString(), this.fetch(new Request(/^https?:\/\//.test(e4) ? e4 : `http://localhost${x(`/`, e4)}`, t3), n2, r2)), "request");
  fire = /* @__PURE__ */ __name(() => {
    addEventListener(`fetch`, (e4) => {
      e4.respondWith(this.#a(e4.request, e4, void 0, e4.request.method));
    });
  }, "fire");
};
var P = /* @__PURE__ */ __name(() => /* @__PURE__ */ Object.create(null), "P");
var F = [];
function de(e4, t3) {
  let n2 = this.buildAllMatchers(), r2 = /* @__PURE__ */ __name(((e5, t4) => {
    let r3 = n2[e5] || n2.ALL, i2 = r3[2][t4];
    if (i2) return i2;
    let a2 = t4.match(r3[0]);
    if (!a2) return [[], F];
    let o2 = a2.indexOf(``, 1);
    return [r3[1][o2], a2];
  }), "r");
  return this.match = r2, r2(e4, t3);
}
__name(de, "de");
var I = `[^/]+`;
var L = `(?:|/.*)`;
var R = /* @__PURE__ */ Symbol();
var z = new Set(`.\\+*[^]$()`);
function B(e4, t3) {
  return e4.length === 1 ? t3.length === 1 ? e4 < t3 ? -1 : 1 : -1 : t3.length === 1 ? 1 : e4 === `.*` || e4 === `(?:|/.*)` ? t3 === `(?:|/.*)` ? -1 : 1 : t3 === `.*` || t3 === `(?:|/.*)` ? -1 : e4 === `[^/]+` ? 1 : t3 === `[^/]+` ? -1 : e4.length === t3.length ? e4 < t3 ? -1 : 1 : t3.length - e4.length;
}
__name(B, "B");
var V = class e2 {
  static {
    __name(this, "e");
  }
  #e;
  #t;
  #n = P();
  insert(t3, n2, r2, i2, a2) {
    let o2 = this;
    for (let n3 = 0, a3 = t3.length; n3 < a3; n3++) {
      let s2 = t3[n3], c2 = s2.length === 1 ? s2 === `*` ? n3 === a3 - 1 ? [``, ``, `.*`] : [``, ``, I] : null : s2 === `/*` ? [``, ``, L] : s2.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/), l2;
      if (c2) {
        let t4 = c2[1], n4 = c2[2] || `[^/]+`;
        if (t4 && c2[2] && (n4 === `.*` || (n4 = n4.replace(/^\((?!\?:)(?=[^)]+\)$)/, `(?:`), /\((?!\?:)/.test(n4)) || n4.length === 1 && z.has(n4))) throw R;
        if (l2 = o2.#n[n4], !l2) {
          if (n4 !== `.*` && n4 !== `(?:|/.*)`) {
            for (let e4 in o2.#n) if ((n4.length > 1 || e4.length > 1) && e4 !== `.*` && e4 !== `(?:|/.*)`) throw R;
          }
          l2 = o2.#n[n4] = new e2();
        }
        t4 !== `` && (l2.#t ??= i2.varIndex++, r2.push([t4, l2.#t]));
      } else if (l2 = o2.#n[s2], !l2) {
        for (let e4 in o2.#n) if (e4.length > 1 && e4 !== `.*` && e4 !== `(?:|/.*)`) throw R;
        l2 = o2.#n[s2] = new e2();
      }
      o2 = l2;
    }
    if (o2.#e !== void 0) throw R;
    o2.#e = a2 ? -1 : n2;
  }
  buildRegExpStr() {
    let e4 = Object.keys(this.#n).sort(B).map((e5) => {
      let t3 = this.#n[e5], n2 = t3.buildRegExpStr();
      return n2 === `` ? `` : (typeof t3.#t == `number` ? `(${e5})@${t3.#t}` : z.has(e5) ? `\\${e5}` : e5) + n2;
    }).filter(Boolean);
    return typeof this.#e == `number` && this.#e !== -1 && e4.unshift(`#${this.#e}`), e4.length === 0 ? `` : e4.length === 1 ? e4[0] : `(?:` + e4.join(`|`) + `)`;
  }
};
var H = class {
  static {
    __name(this, "H");
  }
  #e = { varIndex: 0 };
  #t = new V();
  #n = 0;
  paths = P();
  insert(e4, t3) {
    if (t3) {
      this.#t.insert(e4.split(``), 0, [], this.#e, true);
      return;
    }
    let n2 = [], r2 = [], i2 = e4;
    for (let e5 = 0; ; ) {
      let t4 = false;
      if (i2 = i2.replace(/\{[^}]+\}/g, (n3) => {
        let i3 = `@\\${e5}`;
        return r2[e5] = [i3, n3], e5++, t4 = true, i3;
      }), !t4) break;
    }
    let a2 = i2.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let e5 = r2.length - 1; e5 >= 0; e5--) {
      let [t4] = r2[e5];
      for (let n3 = a2.length - 1; n3 >= 0; n3--) if (a2[n3].indexOf(t4) !== -1) {
        a2[n3] = a2[n3].replace(t4, r2[e5][1]);
        break;
      }
    }
    this.#t.insert(a2, this.#n, n2, this.#e, false), this.paths[e4] = [this.#n++, n2];
  }
  buildRegExp() {
    let e4 = this.#t.buildRegExpStr();
    if (e4 === ``) return [/^$/, [], []];
    let t3 = 0, n2 = [], r2 = [];
    return e4 = e4.replace(/#(\d+)|@(\d+)|\.\*\$/g, (e5, i2, a2) => i2 === void 0 ? (a2 === void 0 || (r2[Number(a2)] = ++t3), ``) : (n2[++t3] = Number(i2), `$()`)), [RegExp(`^${e4}`), n2, r2];
  }
};
var U = P();
function W(e4) {
  return U[e4] ??= RegExp(`^${e4.replace(/\/:[^/{}]+(?:\{\[\^\/]\+})?(?=[/{]|$)|\/?\*$|([.\\+*[^\]$()?{}|])/g, (e5, t3) => t3 ? `\\${t3}` : e5 === `/*` ? L : e5 === `*` ? `.*` : `/:${I}`)}$`);
}
__name(W, "W");
function G(e4, t3) {
  for (let n2 of Object.keys(e4).sort((e5, t4) => t4.length - e5.length)) if (W(n2).test(t3)) return [...e4[n2]];
}
__name(G, "G");
var fe = class {
  static {
    __name(this, "fe");
  }
  name = `RegExpRouter`;
  #e;
  #t;
  #n;
  constructor() {
    this.#e = { ALL: P() }, this.#t = { ALL: P() }, this.#n = { ALL: new H() };
  }
  #r(e4, t3) {
    try {
      this.#n[e4].insert(t3, !/\*|\/:/.test(t3));
    } catch (e5) {
      throw e5 === R ? new M(t3) : e5;
    }
  }
  add(e4, t3, n2) {
    let r2 = this.#e, i2 = this.#t;
    if (!r2) throw Error(j);
    if (!r2[e4]) {
      this.#n[e4] = new H();
      for (let t4 of [r2, i2]) {
        t4[e4] = P();
        for (let n3 in t4.ALL) t4[e4][n3] = [...t4.ALL[n3]], this.#r(e4, n3);
      }
    }
    t3 === `/*` && (t3 = `*`);
    let a2 = e4 === `ALL` ? Object.keys(r2) : [e4];
    if (/\*$/.test(t3)) {
      let e5 = W(t3);
      for (let e6 of a2) r2[e6][t3] || (this.#r(e6, t3), r2[e6][t3] = G(r2[e6], t3) || G(r2.ALL, t3) || []);
      for (let o3 of [r2, i2]) for (let r3 of a2) for (let i3 in o3[r3]) e5.test(i3) && o3[r3][i3].push([n2, t3]);
      return;
    }
    let o2 = S(t3) || [t3];
    for (let e5 of o2) for (let t4 of a2) i2[t4][e5] || (this.#r(t4, e5), i2[t4][e5] = G(r2[t4], e5) || G(r2.ALL, e5) || []), i2[t4][e5].push([n2, e5]);
  }
  match = de;
  buildAllMatchers() {
    let e4 = P();
    for (let t3 of Object.keys(this.#t)) e4[t3] = this.#i(t3);
    return this.#e = this.#t = this.#n = void 0, U = P(), e4;
  }
  #i(e4) {
    let t3 = this.#e[e4], n2 = this.#t[e4], r2 = this.#n[e4], i2 = P(), a2 = [], [o2, s2, c2] = r2.buildRegExp();
    for (let e5 of [t3, n2]) for (let t4 in e5) {
      let n3 = e5[t4], o3 = r2.paths[t4];
      if (!o3) {
        i2[t4] = [n3.map(([e6]) => [e6, P()]), F];
        continue;
      }
      a2[o3[0]] = n3.map(([e6, t5]) => [e6, r2.paths[t5][1].reduceRight((e7, [t6], n4) => (e7[t6] = c2[o3[1][n4][1]], e7), P())]);
    }
    return [o2, s2.map((e5) => a2[e5]), i2];
  }
};
var pe = class {
  static {
    __name(this, "pe");
  }
  name = `SmartRouter`;
  #e = [];
  #t = [];
  constructor(e4) {
    this.#e = e4.routers;
  }
  add(e4, t3, n2) {
    if (!this.#t) throw Error(j);
    this.#t.push([e4, t3, n2]);
  }
  match(e4, t3) {
    if (!this.#t) throw Error(`Fatal error`);
    let n2 = this.#e, r2 = this.#t, i2 = n2.length, a2 = 0, o2;
    for (; a2 < i2; a2++) {
      let i3 = n2[a2];
      try {
        for (let e5 = 0, t4 = r2.length; e5 < t4; e5++) i3.add(...r2[e5]);
        o2 = i3.match(e4, t3);
      } catch (e5) {
        if (e5 instanceof M) continue;
        throw e5;
      }
      this.match = i3.match.bind(i3), this.#e = [i3], this.#t = void 0;
      break;
    }
    if (a2 === i2) throw Error(`Fatal error`);
    return this.name = `SmartRouter + ${this.activeRouter.name}`, o2;
  }
  get activeRouter() {
    if (this.#t || this.#e.length !== 1) throw Error(`No active router has been determined yet.`);
    return this.#e[0];
  }
};
var K = P();
var me = 0;
var he = class e3 {
  static {
    __name(this, "e");
  }
  #e = [];
  #t = P();
  #n = [];
  #r;
  #i = K;
  insert(t3, n2, r2) {
    let i2 = this, a2 = p(n2), o2 = /* @__PURE__ */ new Set(), s2 = 0;
    for (let t4 of a2) {
      let n3 = a2[++s2], r3 = _(t4, n3) || (n3 === void 0 && t4 && t4.indexOf(`*`) === t4.length - 1 ? t4 : null), c2 = Array.isArray(r3), l2 = c2 ? r3[0] : r3 || t4, u2 = i2.#t[l2] ||= new e3();
      r3 && !u2.#r && (u2.#r = r3, i2.#n.push(u2)), i2 = u2, c2 && o2.add(r3[1]);
    }
    i2.#e.push({ [t3]: { handler: r2, possibleKeys: [...o2], score: ++me } });
  }
  #a(e4, t3, n2, r2, i2) {
    for (let a2 = 0, o2 = t3.#e.length; a2 < o2; a2++) {
      let o3 = t3.#e[a2], s2 = o3[n2] || o3.ALL;
      if (s2) {
        s2.params = P(), e4.push(s2);
        for (let e5 = 0, t4 = s2.possibleKeys.length; e5 < t4; e5++) {
          let t5 = s2.possibleKeys[e5];
          s2.params[t5] = i2?.[t5] && !e5 ? i2[t5] : r2[t5] ?? i2?.[t5];
        }
      }
    }
  }
  search(e4, t3) {
    let n2 = [];
    this.#i = K;
    let r2 = [this], i2 = f(t3), a2 = [], o2 = i2.length, s2 = null;
    for (let c2 = 0; c2 < o2; c2++) {
      let l2 = i2[c2], u2 = c2 === o2 - 1, d2 = [];
      for (let f3 = 0, p2 = r2.length; f3 < p2; f3++) {
        let p3 = r2[f3], m2 = p3.#t[l2];
        m2 && (m2.#i = p3.#i, u2 ? (m2.#t[`*`] && this.#a(n2, m2.#t[`*`], e4, p3.#i), this.#a(n2, m2, e4, p3.#i)) : d2.push(m2));
        for (let r3 of p3.#n) {
          let f4 = r3.#r, m3 = p3.#i === K ? {} : { ...p3.#i };
          if (typeof f4 == `string`) {
            (f4 === `*` || l2.startsWith(f4.slice(0, -1))) && (this.#a(n2, r3, e4, p3.#i), f4 === `*` && (r3.#i = m3, d2.push(r3)));
            continue;
          }
          let [, h2, g2] = f4;
          if (!(!l2 && g2 === true)) {
            if (g2 !== true) {
              if (!s2) {
                s2 = [];
                let e5 = +(t3[0] === `/`);
                for (let t4 = 0; t4 < o2; t4++) s2[t4] = e5, e5 += i2[t4].length + 1;
              }
              let l3 = t3.slice(s2[c2]), u3 = g2.exec(l3);
              if (u3) {
                m3[h2] = u3[0], this.#a(n2, r3, e4, p3.#i, m3), u3[0].length === l3.length && r3.#t[`*`] && this.#a(n2, r3.#t[`*`], e4, p3.#i, m3);
                for (let e5 in r3.#t) {
                  r3.#i = m3;
                  let e6 = u3[0].match(/\//g)?.length ?? 0;
                  (a2[e6] ||= []).push(r3);
                  break;
                }
                continue;
              }
            }
            (g2 === true || g2.test(l2)) && (m3[h2] = l2, u2 ? (this.#a(n2, r3, e4, m3, p3.#i), r3.#t[`*`] && this.#a(n2, r3.#t[`*`], e4, m3, p3.#i)) : (r3.#i = m3, d2.push(r3)));
          }
        }
      }
      let f2 = a2.shift();
      r2 = f2 ? d2.concat(f2) : d2;
    }
    return n2[1] && n2.sort((e5, t4) => e5.score - t4.score), [n2.map(({ handler: e5, params: t4 }) => [e5, t4])];
  }
};
var ge = class {
  static {
    __name(this, "ge");
  }
  name = `TrieRouter`;
  #e = new he();
  add(e4, t3, n2) {
    for (let r2 of S(t3) || [t3]) this.#e.insert(e4, r2, n2);
  }
  match(e4, t3) {
    return this.#e.search(e4, t3);
  }
};
var q = class extends ue {
  static {
    __name(this, "q");
  }
  constructor(e4 = {}) {
    super(e4), this.router = e4.router ?? new pe({ routers: [new fe(), new ge()] });
  }
};
var _e = /^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|msgpack|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|vnd\.msgpack|wasm|x-httpd-php|x-javascript|x-msgpack|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml|msgpack))(?:[;\s]|$)/i;
var J = /* @__PURE__ */ __name((e4, t3 = ve) => {
  let n2 = e4.match(/\.([a-zA-Z0-9]+?)$/);
  if (n2) return t3[n2[1].toLowerCase()];
}, "J");
var ve = { aac: `audio/aac`, avi: `video/x-msvideo`, avif: `image/avif`, av1: `video/av1`, bin: `application/octet-stream`, bmp: `image/bmp`, css: `text/css; charset=utf-8`, csv: `text/csv; charset=utf-8`, eot: `application/vnd.ms-fontobject`, epub: `application/epub+zip`, gif: `image/gif`, gz: `application/gzip`, htm: `text/html; charset=utf-8`, html: `text/html; charset=utf-8`, ico: `image/x-icon`, ics: `text/calendar; charset=utf-8`, jpeg: `image/jpeg`, jpg: `image/jpeg`, js: `text/javascript; charset=utf-8`, json: `application/json`, jsonld: `application/ld+json`, map: `application/json`, mid: `audio/x-midi`, midi: `audio/x-midi`, mjs: `text/javascript; charset=utf-8`, mp3: `audio/mpeg`, mp4: `video/mp4`, mpeg: `video/mpeg`, oga: `audio/ogg`, ogv: `video/ogg`, ogx: `application/ogg`, opus: `audio/opus`, otf: `font/otf`, pdf: `application/pdf`, png: `image/png`, rtf: `application/rtf`, svg: `image/svg+xml; charset=utf-8`, tif: `image/tiff`, tiff: `image/tiff`, ts: `video/mp2t`, ttf: `font/ttf`, txt: `text/plain; charset=utf-8`, wasm: `application/wasm`, webm: `video/webm`, weba: `audio/webm`, webmanifest: `application/manifest+json`, webp: `image/webp`, woff: `font/woff`, woff2: `font/woff2`, xhtml: `application/xhtml+xml; charset=utf-8`, xml: `application/xml; charset=utf-8`, zip: `application/zip`, "3gp": `video/3gpp`, "3g2": `video/3gpp2`, gltf: `model/gltf+json`, glb: `model/gltf-binary` };
var ye = /* @__PURE__ */ __name((...e4) => {
  let t3 = e4.filter((e5) => e5 !== ``).join(`/`);
  t3 = t3.replace(/(?<=\/)\/+/g, ``);
  let n2 = t3.split(`/`), r2 = [];
  for (let e5 of n2) e5 === `..` && r2.length > 0 && r2.at(-1) !== `..` ? r2.pop() : e5 !== `.` && r2.push(e5);
  return r2.join(`/`) || `.`;
}, "ye");
var Y = { br: `.br`, zstd: `.zst`, gzip: `.gz` };
var be = Object.keys(Y);
var xe = `index.html`;
var Se = /* @__PURE__ */ __name((e4) => {
  let t3 = e4.root ?? `./`, n2 = e4.path, r2 = e4.join ?? ye;
  return async (i2, a2) => {
    if (i2.finalized) return a2();
    let o2;
    if (e4.path) o2 = e4.path;
    else try {
      if (o2 = y(i2.req.path), /(?:^|[\/\\])\.{1,2}(?:$|[\/\\])|[\/\\]{2,}|\\/.test(o2)) throw Error();
    } catch {
      return await e4.onNotFound?.(i2.req.path, i2), a2();
    }
    let s2 = r2(t3, !n2 && e4.rewriteRequestPath ? e4.rewriteRequestPath(o2) : o2);
    e4.isDir && await e4.isDir(s2) && (s2 = r2(s2, xe));
    let c2 = e4.getContent, l2 = await c2(s2, i2);
    if (l2 instanceof Response) return i2.newResponse(l2.body, l2);
    if (l2 != null) {
      let t4 = e4.mimes && J(s2, e4.mimes) || J(s2);
      if (i2.header(`Content-Type`, t4 || `application/octet-stream`), e4.precompressed && (!t4 || _e.test(t4))) {
        let e5 = new Set(i2.req.header(`Accept-Encoding`)?.split(`,`).map((e6) => e6.trim()));
        for (let t5 of be) {
          if (!e5.has(t5)) continue;
          let n3 = await c2(s2 + Y[t5], i2);
          if (n3) {
            l2 = n3, i2.header(`Content-Encoding`, t5), i2.header(`Vary`, `Accept-Encoding`, { append: true });
            break;
          }
        }
      }
      return await e4.onFound?.(s2, i2), i2.body(l2);
    }
    await e4.onNotFound?.(s2, i2), await a2();
  };
}, "Se");
var Ce = /* @__PURE__ */ __name(async (e4, t3) => {
  let n2;
  n2 = t3 && t3.manifest ? typeof t3.manifest == `string` ? JSON.parse(t3.manifest) : t3.manifest : typeof __STATIC_CONTENT_MANIFEST == `string` ? JSON.parse(__STATIC_CONTENT_MANIFEST) : __STATIC_CONTENT_MANIFEST;
  let r2;
  r2 = t3 && t3.namespace ? t3.namespace : __STATIC_CONTENT;
  let i2 = n2[e4];
  return i2 && await r2.get(i2, { type: `stream` }) || null;
}, "Ce");
var X = /* @__PURE__ */ __name((e4 = {}) => async function(t3, n2) {
  let r2 = /* @__PURE__ */ __name(async (n3) => Ce(n3, { manifest: e4.manifest, namespace: e4.namespace ? e4.namespace : t3.env ? t3.env.__STATIC_CONTENT : void 0 }), "r");
  return Se({ ...e4, getContent: r2 })(t3, n2);
}, "X");
var we = /* @__PURE__ */ __name((e4) => X(e4), "we");
var Z = new q();
Z.use(`/static/*`, we({ root: `./public` })), Z.get(`/`, (e4) => e4.html(Te));
var Te = `<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Prasad Anand \u2014 AI/ML Engineer</title>
<meta name="description" content="Prasad Anand \u2014 computer engineering student and AI/ML intern in Pune, IN. Applied machine learning, NLP systems, and pragmatic backend engineering." />
<meta property="og:title" content="Prasad Anand \u2014 AI/ML Engineer" />
<meta property="og:description" content="Computer engineering student and AI/ML intern in Pune, IN. Applied machine learning, NLP systems, and pragmatic backend engineering." />
<meta property="og:type" content="website" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;1,9..144,400&display=swap" rel="stylesheet">
<link href="/static/style.css" rel="stylesheet" />
</head>
<body>

<!-- ============ TOP BAR ============ -->
<header class="topbar">
  <div class="wrap topbar-inner">
    <div class="brand">
      <span class="dot"></span>
      <span>prasad_anand</span>
      <small>&middot; v2.026</small>
    </div>
    <nav class="nav" aria-label="Primary">
      <a href="#work" class="on">work</a>
      <a href="#about">about</a>
      <a href="#skills">skills</a>
      <a href="#experience">experience</a>
      <a href="#projects">projects</a>
      <a href="#contact">contact</a>
    </nav>
    <div class="top-right">
      <span class="status"><span class="pulse" aria-hidden="true"></span> available &middot; IST</span>
      <button class="theme-toggle" id="themeToggle" type="button" aria-label="Toggle color theme">&mdash; light</button>
    </div>
  </div>
</header>

<main id="main-content">

<!-- ============ HERO ============ -->
<section class="hero" id="work" aria-label="Introduction">
  <div class="wrap">

    <p class="hero-meta">
      <span>portfolio / 2026</span>
      <span>pune, IN</span>
      <span>lat 18.51&deg;N &middot; lon 73.85&deg;E</span>
    </p>

    <div class="hero-grid">
      <div>
        <h1 class="hero-title">
          Prasad <span class="accent">Anand</span>.
        </h1>
        <p class="hero-role">
          <span class="k">ML Intern @ Cubeage Technologies Pvt. Ltd.</span> &mdash; building applied ML pipelines
          and <span class="k">NLP systems</span>. Currently developing
          <span class="k">DocuSense</span>, a document analyzer that extracts structured meaning from
          contracts, agreements &amp; resumes using local LLMs (Qwen&nbsp;2.5&nbsp;7B) and Gemini.
          Previously ML intern @ Tantrata Digital.
        </p>
        <div class="hero-cta">
          <a href="#projects" class="btn primary">view projects <span class="arrow" aria-hidden="true">&rarr;</span></a>
          <a href="#contact" class="btn">get in touch</a>
        </div>
      </div>

      <!-- Notebook cell block -->
      <div class="notebook" role="img" aria-label="Notebook cell demonstrating Prasad's engineer bio, a training loss curve, and a live command prompt">
        <div class="cell md">
          <div class="cell-gutter">md</div>
          <div class="cell-body"># prasad_bio.ipynb &middot; cell 01</div>
        </div>
        <div class="cell">
          <div class="cell-gutter"><span class="marker">In [1]:</span></div>
          <div class="cell-body code"><span class="tok-kw">from</span> prasad <span class="tok-kw">import</span> Engineer

me = Engineer(
    role=<span class="tok-str">"ML Intern"</span>,
    org=<span class="tok-str">"Cubeage Technologies"</span>,
    stack=[<span class="tok-str">"python"</span>, <span class="tok-str">"pytorch"</span>, <span class="tok-str">"nlp"</span>],
    building=<span class="tok-str">"docusense &middot; nlp pipelines"</span>,
)
me.<span class="tok-fn">summary</span>()<span class="caret" aria-hidden="true"></span></div>
        </div>
        <div class="cell out">
          <div class="cell-gutter">Out[1]:</div>
          <div class="cell-body">
            <div><span class="tok-comment"># training curve &middot; docusense classifier v2</span></div>
            <svg class="mini-chart" viewBox="0 0 300 60" preserveAspectRatio="none" aria-hidden="true">
              <defs>
                <pattern id="ga" width="30" height="15" patternUnits="userSpaceOnUse">
                  <path d="M30 0 L0 0 0 15" fill="none" stroke="currentColor" stroke-width="0.3" opacity="0.25"/>
                </pattern>
              </defs>
              <rect width="300" height="60" fill="url(#ga)"/>
              <polyline fill="none" stroke="var(--muted)" stroke-width="1"
                points="0,10 40,14 80,20 120,28 160,36 200,44 240,50 280,54 300,55" opacity="0.6"/>
              <polyline fill="none" stroke="var(--accent)" stroke-width="1.4"
                points="0,55 40,42 80,32 120,26 160,20 200,16 240,13 280,11 300,10"/>
              <circle cx="300" cy="10" r="2.2" fill="var(--accent)"/>
            </svg>
            <div style="display:flex; justify-content:space-between; font-size:10.5px; margin-top:4px;">
              <span>epoch 0</span><span>loss &darr; 0.021</span><span>epoch 50</span>
            </div>
          </div>
        </div>
        <div class="cell">
          <div class="cell-gutter"><span class="marker">In [2]:</span></div>
          <div class="cell-body code" id="live-cell" aria-hidden="true"></div>
        </div>
      </div>
    </div>

    <dl class="coords">
      <div><dt>current focus</dt><dd>NLP &middot; document AI &middot; LLM pipelines</dd></div>
      <div><dt>internships</dt><dd>02 completed &middot; 01 active</dd></div>
      <div><dt>open to</dt><dd>Remote &middot; Collab &middot; Research</dd></div>
      <div><dt>last commit</dt><dd id="last-commit">&mdash;</dd></div>
    </dl>

  </div>
</section>

<!-- ============ ABOUT ============ -->
<section class="section" id="about" aria-labelledby="about-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 01</b> / about</div>
      <div>
        <h2 class="section-title" id="about-title">A short <i>readme</i>.</h2>
        <p class="section-sub">Where I come from, what I work on, and what I'm optimising for.</p>
      </div>
    </div>

    <div class="about-body">
      <div></div>
      <div class="about-prose">
        <p class="lead">
          I'm a computer engineering student and software intern based in Pune, working at the
          intersection of <em>applied machine learning</em> and pragmatic backend systems.
        </p>
        <p>
          My work sits between two disciplines. On one side, training and evaluating models &mdash;
          currently focused on sequence models (LSTM, small transformers) for financial and
          health-signal data. On the other, the unglamorous plumbing that makes them useful:
          ETL, schema design in PostgreSQL, deployment on Vercel/Supabase.
        </p>
        <p>
          I write C++ when the problem calls for it &mdash; graph algorithms, competitive programming,
          anything where the constant factor matters. Python is where I <em>think</em>; C++ is
          where I <em>measure</em>.
        </p>
      </div>

      <!-- Confusion matrix figure -->
      <figure class="about-figure" style="margin:0;">
        <svg viewBox="0 0 240 200" width="100%" role="img" aria-labelledby="cm-title cm-desc">
          <title id="cm-title">Confusion matrix, 4-class classifier</title>
          <desc id="cm-desc">A 4x4 confusion matrix heatmap with diagonal accuracy values 0.85, 0.78, 0.72 and 0.90.</desc>
          <style>
            .cm-t { font: 10px 'JetBrains Mono', monospace; fill: var(--muted); }
            .cm-h { font: 9px 'JetBrains Mono', monospace; fill: var(--muted-2); letter-spacing: 0.05em; }
          </style>
          <text class="cm-h" x="120" y="14" text-anchor="middle">predicted &rarr;</text>
          <text class="cm-h" x="10" y="110" text-anchor="middle" transform="rotate(-90 10 110)">actual &rarr;</text>

          <!-- axis labels -->
          <text class="cm-t" x="50" y="30" text-anchor="middle">A</text>
          <text class="cm-t" x="110" y="30" text-anchor="middle">B</text>
          <text class="cm-t" x="170" y="30" text-anchor="middle">C</text>
          <text class="cm-t" x="230" y="30" text-anchor="middle">D</text>
          <text class="cm-t" x="26" y="64" text-anchor="middle">A</text>
          <text class="cm-t" x="26" y="104" text-anchor="middle">B</text>
          <text class="cm-t" x="26" y="144" text-anchor="middle">C</text>
          <text class="cm-t" x="26" y="184" text-anchor="middle">D</text>

          <!-- 4x4 grid -->
          <g transform="translate(40,40)">
            <!-- row 1 -->
            <rect x="0"   y="0"  width="40" height="40" fill="var(--accent)" opacity="0.85"/>
            <rect x="40"  y="0"  width="40" height="40" fill="var(--accent)" opacity="0.1"/>
            <rect x="80"  y="0"  width="40" height="40" fill="var(--accent)" opacity="0.05"/>
            <rect x="120" y="0"  width="40" height="40" fill="var(--accent)" opacity="0.12"/>
            <!-- row 2 -->
            <rect x="0"   y="40" width="40" height="40" fill="var(--accent)" opacity="0.08"/>
            <rect x="40"  y="40" width="40" height="40" fill="var(--accent)" opacity="0.78"/>
            <rect x="80"  y="40" width="40" height="40" fill="var(--accent)" opacity="0.15"/>
            <rect x="120" y="40" width="40" height="40" fill="var(--accent)" opacity="0.03"/>
            <!-- row 3 -->
            <rect x="0"   y="80" width="40" height="40" fill="var(--accent)" opacity="0.05"/>
            <rect x="40"  y="80" width="40" height="40" fill="var(--accent)" opacity="0.18"/>
            <rect x="80"  y="80" width="40" height="40" fill="var(--accent)" opacity="0.72"/>
            <rect x="120" y="80" width="40" height="40" fill="var(--accent)" opacity="0.09"/>
            <!-- row 4 -->
            <rect x="0"   y="120" width="40" height="40" fill="var(--accent)" opacity="0.02"/>
            <rect x="40"  y="120" width="40" height="40" fill="var(--accent)" opacity="0.06"/>
            <rect x="80"  y="120" width="40" height="40" fill="var(--accent)" opacity="0.14"/>
            <rect x="120" y="120" width="40" height="40" fill="var(--accent)" opacity="0.9"/>
            <!-- grid lines -->
            <g stroke="var(--bg)" stroke-width="1" fill="none">
              <line x1="40" y1="0" x2="40" y2="160"/>
              <line x1="80" y1="0" x2="80" y2="160"/>
              <line x1="120" y1="0" x2="120" y2="160"/>
              <line x1="0" y1="40" x2="160" y2="40"/>
              <line x1="0" y1="80" x2="160" y2="80"/>
              <line x1="0" y1="120" x2="160" y2="120"/>
            </g>
            <!-- numbers -->
            <g style="font: 10px 'JetBrains Mono', monospace; fill: var(--bg); text-anchor: middle;">
              <text x="20" y="25">0.85</text>
              <text x="60" y="65">0.78</text>
              <text x="100" y="105">0.72</text>
              <text x="140" y="145">0.90</text>
            </g>
          </g>
        </svg>
        <figcaption class="figure-cap">
          <b>fig. 01</b> &mdash; confusion matrix, 4-class classifier &middot; val_acc = 0.81
        </figcaption>
      </figure>
    </div>
  </div>
</section>

<div class="cli-strip">
  <div class="wrap cli-strip-inner">
    <span><span class="prompt">$</span> <span class="cmd">cat ~/portfolio/skills.yaml</span></span>
    <span class="sep">|</span>
    <span class="out">21 tools &middot; 4 tiers &middot; sorted by comfort</span>
    <span class="sep">|</span>
    <span><span class="prompt">$</span> <span class="cmd">tier=1 grep .</span></span>
    <span class="out">python, c++, numpy, postgres, git, linux</span>
  </div>
</div>

<!-- ============ SKILLS ============ -->
<section class="section" id="skills" aria-labelledby="skills-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 02</b> / stack</div>
      <div>
        <h2 class="section-title" id="skills-title">Working <i>toolkit</i>.</h2>
        <p class="section-sub">Ordered by comfort and time-under-the-hood, not by hype. Row 1 is where I ship daily.</p>
      </div>
    </div>

    <div class="skills-row">
      <div class="skills-row-label"><span class="num">01</span> &middot; daily driver</div>
      <div class="skills-cloud">
        <span class="chip t1">Python <span class="lvl">// primary</span></span>
        <span class="chip t1">C / C++ <span class="lvl">// perf</span></span>
        <span class="chip t1">NumPy</span>
        <span class="chip t1">PostgreSQL</span>
        <span class="chip t1">Git</span>
        <span class="chip t1">Linux shell</span>
      </div>
    </div>

    <div class="skills-row">
      <div class="skills-row-label"><span class="num">02</span> &middot; comfortable</div>
      <div class="skills-cloud">
        <span class="chip t2">PyTorch</span>
        <span class="chip t2">TensorFlow / Keras</span>
        <span class="chip t2">scikit-learn</span>
        <span class="chip t2">Matplotlib</span>
        <span class="chip t2">Pandas</span>
        <span class="chip t2">JavaScript &middot; ES2022</span>
        <span class="chip t2">React</span>
        <span class="chip t2">Tailwind</span>
        <span class="chip t2">Supabase</span>
      </div>
    </div>

    <div class="skills-row">
      <div class="skills-row-label"><span class="num">03</span> &middot; exploring</div>
      <div class="skills-cloud">
        <span class="chip t3">NLP &middot; spaCy &middot; Transformers</span>
        <span class="chip t3">Local LLMs &middot; Ollama &middot; Qwen 2.5</span>
        <span class="chip t3">Gemini API</span>
        <span class="chip t3">CUDA basics</span>
        <span class="chip t3">Docker</span>
        <span class="chip t3">FastAPI</span>
        <span class="chip t3">Vercel edge</span>
        <span class="chip t3">DuckDB</span>
        <span class="chip t3">Rust</span>
      </div>
    </div>

    <div class="skills-row">
      <div class="skills-row-label"><span class="num">04</span> &middot; foundations</div>
      <div class="skills-cloud">
        <span class="chip t3">Data structures &amp; algorithms</span>
        <span class="chip t3">Graph algorithms</span>
        <span class="chip t3">Linear algebra</span>
        <span class="chip t3">Probability &amp; statistics</span>
        <span class="chip t3">Competitive programming</span>
        <span class="chip t3">System design (intro)</span>
      </div>
    </div>
  </div>
</section>

<div class="cli-strip">
  <div class="wrap cli-strip-inner">
    <span><span class="prompt">$</span> <span class="cmd">git log --oneline --since="2024-01" ./career</span></span>
    <span class="sep">|</span>
    <span class="out">3 commits &middot; head @ cubeage</span>
    <span class="sep">|</span>
    <span><span class="prompt">$</span> <span class="cmd">whoami</span></span>
    <span class="out">ml_intern &middot; building docusense</span>
  </div>
</div>

<!-- ============ EXPERIENCE ============ -->
<section class="section" id="experience" aria-labelledby="experience-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 03</b> / experience</div>
      <div>
        <h2 class="section-title" id="experience-title">Where I've <i>shipped</i>.</h2>
        <p class="section-sub">Two internships to date, one active. Compact log &mdash; reverse chronological.</p>
      </div>
    </div>

    <div class="xp-table">
      <article class="xp-row">
        <div class="xp-date">JUN 2026 &mdash;<br/>PRESENT</div>
        <div>
          <h3 class="xp-role">ML Intern</h3>
          <div class="xp-company">CUBEAGE TECHNOLOGIES PVT. LTD.</div>
          <p class="xp-desc">
            Building applied ML pipelines and NLP systems. Currently developing
            <em>DocuSense</em>, a document analyzer that reads contracts, rental agreements
            and resumes and extracts key terms, obligations, and ATS-style scoring &mdash;
            powered by local LLMs (Qwen&nbsp;2.5&nbsp;7B via Ollama) and the Gemini API.
          </p>
        </div>
        <div class="xp-tags">
          <span>python</span>
          <span>nlp &middot; transformers</span>
          <span>qwen &middot; gemini</span>
          <span>ollama</span>
        </div>
        <div class="xp-arrow" aria-hidden="true">&rarr;</div>
      </article>

      <article class="xp-row">
        <div class="xp-date">JAN 2026 &mdash;<br/>FEB 2026</div>
        <div>
          <h3 class="xp-role">Software Intern, AI/ML</h3>
          <div class="xp-company">TANTRATA DIGITAL SOLUTIONS PVT. LTD.</div>
          <p class="xp-desc">
            Contributed to specialised software cycles focused on data-driven logic inside
            AI/ML workflows. Built feature-extraction pipelines, model evaluation harnesses,
            and internal tooling in Python.
          </p>
        </div>
        <div class="xp-tags">
          <span>python</span>
          <span>numpy &middot; pandas</span>
          <span>model eval</span>
        </div>
        <div class="xp-arrow" aria-hidden="true">&rarr;</div>
      </article>

      <article class="xp-row">
        <div class="xp-date">JUN 2025 &mdash;<br/>JUL 2025</div>
        <div>
          <h3 class="xp-role">Data Intern</h3>
          <div class="xp-company">GREENFINCH DIGITAL BUSINESS SOLUTIONS PVT. LTD.</div>
          <p class="xp-desc">
            Worked on digital-transformation projects &mdash; data cleaning, business-process
            modelling, and prototype dashboards. Focused summer program.
          </p>
        </div>
        <div class="xp-tags">
          <span>sql</span>
          <span>dashboards</span>
          <span>data modelling</span>
        </div>
        <div class="xp-arrow" aria-hidden="true">&rarr;</div>
      </article>
    </div>
  </div>
</section>

<div class="cli-strip">
  <div class="wrap cli-strip-inner">
    <span><span class="prompt">$</span> <span class="cmd">ls ~/projects</span></span>
    <span class="sep">|</span>
    <span class="out">docusense/&nbsp; oiltrace/&nbsp; wellnesspluss/&nbsp; blood-bank/</span>
    <span class="sep">|</span>
    <span><span class="prompt">$</span> <span class="cmd">wc -l **/*.py</span></span>
    <span class="out">~ 8.4k loc python</span>
  </div>
</div>

<!-- ============ PROJECTS ============ -->
<section class="section" id="projects" aria-labelledby="projects-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 04</b> / selected work</div>
      <div style="display:flex; justify-content:space-between; align-items:baseline; gap:24px; flex-wrap:wrap;">
        <div>
          <h2 class="section-title" id="projects-title">Selected <i>works</i>.</h2>
          <p class="section-sub">A short set of projects that show how I think &mdash; across ML, systems, and web.</p>
        </div>
        <div class="proj-filter" role="tablist" aria-label="Filter projects">
          <button class="filter-btn on" data-filter="all" role="tab" aria-selected="true">all &middot; 04</button>
          <button class="filter-btn" data-filter="ml" role="tab" aria-selected="false">ml / nlp</button>
          <button class="filter-btn" data-filter="sys" role="tab" aria-selected="false">systems</button>
          <button class="filter-btn" data-filter="web" role="tab" aria-selected="false">web</button>
        </div>
      </div>
    </div>

    <div class="proj-grid">

      <!-- 01 DocuSense (wide feature) -->
      <article class="proj wide" data-tags="ml">
        <div class="proj-head">
          <span class="proj-idx">01 &middot; nlp &middot; document AI</span>
          <span class="proj-status live">shipped</span>
        </div>
        <div class="proj-figure">
          <!-- Document -> tokens -> extracted fields diagram -->
          <svg viewBox="0 0 400 150" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Diagram: a rental agreement document is processed by Qwen 2.5 7B into tokenized fields, then converted to structured JSON output with tenant, rent, term, notice, risks and score keys">
            <!-- document page -->
            <g fill="none" stroke="var(--rule-strong)" stroke-width="0.8">
              <rect x="20" y="20" width="90" height="110"/>
            </g>
            <g stroke="var(--muted-2)" stroke-width="1" opacity="0.55">
              <line x1="30" y1="34" x2="92" y2="34"/>
              <line x1="30" y1="44" x2="85" y2="44"/>
              <line x1="30" y1="54" x2="100" y2="54"/>
            </g>
            <g stroke="var(--accent)" stroke-width="1.2">
              <line x1="30" y1="68" x2="70" y2="68"/>
              <line x1="30" y1="84" x2="88" y2="84"/>
            </g>
            <g stroke="var(--muted-2)" stroke-width="1" opacity="0.55">
              <line x1="30" y1="96" x2="98" y2="96"/>
              <line x1="30" y1="106" x2="80" y2="106"/>
              <line x1="30" y1="116" x2="92" y2="116"/>
            </g>
            <text x="20" y="14" style="font:9px 'JetBrains Mono',monospace; fill:var(--muted); letter-spacing:0.05em">rental_agreement.pdf</text>

            <!-- arrow -->
            <g stroke="var(--rule-strong)" stroke-width="0.8" fill="none">
              <line x1="115" y1="75" x2="165" y2="75" stroke-dasharray="3 3"/>
              <path d="M162 71 L168 75 L162 79" stroke="var(--accent)"/>
            </g>
            <text x="140" y="70" text-anchor="middle" style="font:8.5px 'JetBrains Mono',monospace; fill:var(--accent)">qwen2.5 7b</text>

            <!-- token stream -->
            <g style="font:9px 'JetBrains Mono',monospace; fill:var(--ink-strong)">
              <rect x="175" y="30"  width="70" height="14" fill="none" stroke="var(--rule-strong)" stroke-width="0.6"/>
              <text x="179" y="40">tenant</text>
              <rect x="175" y="50"  width="70" height="14" fill="none" stroke="var(--rule-strong)" stroke-width="0.6"/>
              <text x="179" y="60">rent &middot; term</text>
              <rect x="175" y="70"  width="70" height="14" fill="var(--accent)" opacity="0.9"/>
              <text x="179" y="80" fill="var(--bg)">clauses &middot; 12</text>
              <rect x="175" y="90"  width="70" height="14" fill="none" stroke="var(--rule-strong)" stroke-width="0.6"/>
              <text x="179" y="100">notice period</text>
              <rect x="175" y="110" width="70" height="14" fill="none" stroke="var(--rule-strong)" stroke-width="0.6"/>
              <text x="179" y="120">obligations</text>
            </g>

            <!-- second arrow -->
            <g stroke="var(--rule-strong)" stroke-width="0.8" fill="none">
              <line x1="250" y1="75" x2="290" y2="75" stroke-dasharray="3 3"/>
              <path d="M287 71 L293 75 L287 79" stroke="var(--accent)"/>
            </g>

            <!-- json output -->
            <g fill="none" stroke="var(--rule)" stroke-width="0.8">
              <rect x="298" y="25" width="92" height="105"/>
            </g>
            <g style="font:9.5px 'JetBrains Mono',monospace; fill:var(--muted)">
              <text x="304" y="40">&#123;</text>
              <text x="310" y="52"><tspan fill="var(--accent)">"tenant"</tspan>: "...",</text>
              <text x="310" y="64"><tspan fill="var(--accent)">"rent"</tspan>: 24000,</text>
              <text x="310" y="76"><tspan fill="var(--accent)">"term"</tspan>: "11m",</text>
              <text x="310" y="88"><tspan fill="var(--accent)">"notice"</tspan>: 30,</text>
              <text x="310" y="100"><tspan fill="var(--accent)">"risks"</tspan>: [2],</text>
              <text x="310" y="112"><tspan fill="var(--accent)">"score"</tspan>: 0.94</text>
              <text x="304" y="124">&#125;</text>
            </g>
            <text x="390" y="14" text-anchor="end" style="font:9px 'JetBrains Mono',monospace; fill:var(--muted); letter-spacing:0.05em">extracted.json</text>
          </svg>
        </div>
        <h3 class="proj-title">DocuSense &mdash; Document Extractor</h3>
        <p class="proj-desc">
          A document analyzer that reads any long-form document &mdash; land registration, rental
          agreements, resumes &mdash; and returns the important terms, clauses and risks as
          structured data. For resumes it produces an ATS-style score. Runs on <em>local LLMs</em>
          (Qwen 2.5 7B via Ollama) with the Google Gemini API as a fallback. Building this
          currently at Cubeage Technologies.
        </p>
        <div class="proj-foot">
          <div class="proj-stack">
            <span><b>Python</b></span>
            <span><b>Qwen 2.5</b></span>
            <span><b>Gemini</b></span>
            <span><b>Ollama</b></span>
          </div>
          <a class="proj-link" href="https://github.com/prasadanand412/DocuSense-document-extractor" target="_blank" rel="noopener">github &#8599;</a>
        </div>
      </article>

      <!-- 02 OilTrace (narrow) -->
      <article class="proj narrow" data-tags="ml sys">
        <div class="proj-head">
          <span class="proj-idx">02 &middot; sat imagery &middot; SIH</span>
          <span class="proj-status">in development</span>
        </div>
        <div class="proj-figure">
          <!-- satellite tile + oil spill + backtrace arrow -->
          <svg viewBox="0 0 140 100" width="100%" height="100%" role="img" aria-label="Diagram: an oil spill detected on a satellite ocean tile, with a backtrace arrow pointing to a predicted source location, factoring in wind direction">
            <!-- ocean tile grid -->
            <defs>
              <pattern id="sea" width="12" height="12" patternUnits="userSpaceOnUse">
                <rect width="12" height="12" fill="var(--bg)"/>
                <path d="M12 0 L0 0 0 12" fill="none" stroke="var(--rule-strong)" stroke-width="0.25" opacity="0.55"/>
              </pattern>
            </defs>
            <rect x="10" y="10" width="120" height="80" fill="url(#sea)" stroke="var(--rule-strong)" stroke-width="0.6"/>
            <!-- oil spill blob -->
            <path d="M92,42 C102,38 112,44 110,54 C114,62 104,68 96,64 C88,68 82,58 88,52 C84,46 88,42 92,42 Z"
                  fill="var(--accent)" opacity="0.85"/>
            <path d="M92,42 C102,38 112,44 110,54 C114,62 104,68 96,64 C88,68 82,58 88,52 C84,46 88,42 92,42 Z"
                  fill="none" stroke="var(--accent)" stroke-width="0.6" opacity="0.6"/>
            <!-- backtrace arrow -->
            <path d="M96 54 Q75 40 45 30" fill="none" stroke="var(--accent)" stroke-width="1.2" stroke-dasharray="3 2"/>
            <path d="M48 32 L42 28 L46 34 Z" fill="var(--accent)"/>
            <!-- source point (predicted) -->
            <circle cx="42" cy="28" r="3" fill="none" stroke="var(--accent)" stroke-width="1"/>
            <circle cx="42" cy="28" r="1.4" fill="var(--accent)"/>
            <!-- wind vector -->
            <g stroke="var(--muted)" stroke-width="0.5" opacity="0.7">
              <line x1="20" y1="20" x2="32" y2="20"/>
              <line x1="30" y1="18" x2="32" y2="20"/>
              <line x1="30" y1="22" x2="32" y2="20"/>
            </g>
            <text x="14" y="18" style="font:7px 'JetBrains Mono',monospace; fill:var(--muted)">wind</text>
            <text x="42" y="22" text-anchor="middle" style="font:7px 'JetBrains Mono',monospace; fill:var(--accent)">src?</text>
            <text x="100" y="78" text-anchor="middle" style="font:7px 'JetBrains Mono',monospace; fill:var(--accent)">spill</text>
          </svg>
        </div>
        <h3 class="proj-title">OilTrace &mdash; Spill Origin Tracer</h3>
        <p class="proj-desc">
          SIH project. Analyses satellite imagery to detect oil spills, then backtraces
          the drift to the actual source using particle physics and environmental factors:
          wind speed, sea-surface temperature, water flow, tide and current.
        </p>
        <div class="proj-foot">
          <div class="proj-stack">
            <span><b>PyTorch</b></span>
            <span><b>CUDA</b></span>
          </div>
          <a class="proj-link" href="https://github.com/prasadanand412/oiltrace" target="_blank" rel="noopener">github &#8599;</a>
        </div>
      </article>

      <!-- 03 WellnessPlus (half) -->
      <article class="proj" data-tags="web ml">
        <div class="proj-head">
          <span class="proj-idx">03 &middot; full-stack + health signals</span>
          <span class="proj-status live">live</span>
        </div>
        <div class="proj-figure">
          <!-- steps bar + HR baseline + symptom -> prediction -->
          <svg viewBox="0 0 300 100" width="100%" height="100%" preserveAspectRatio="none" role="img" aria-label="Chart: daily step-count bars overlaid with a heart-rate trace, trending toward a symptom-based prediction">
            <defs>
              <pattern id="pg2" width="30" height="20" patternUnits="userSpaceOnUse">
                <path d="M30 0 L0 0 0 20" fill="none" stroke="currentColor" stroke-width="0.3" opacity="0.18"/>
              </pattern>
            </defs>
            <rect width="300" height="100" fill="url(#pg2)"/>
            <!-- steps bars -->
            <g fill="var(--accent)" opacity="0.85">
              <rect x="14"  y="60" width="10" height="30"/>
              <rect x="30"  y="48" width="10" height="42"/>
              <rect x="46"  y="52" width="10" height="38"/>
              <rect x="62"  y="38" width="10" height="52"/>
              <rect x="78"  y="30" width="10" height="60"/>
              <rect x="94"  y="56" width="10" height="34"/>
              <rect x="110" y="42" width="10" height="48"/>
            </g>
            <!-- HR trace overlay -->
            <polyline fill="none" stroke="var(--muted)" stroke-width="1" opacity="0.9"
              points="140,60 160,60 165,25 170,80 175,60 200,60 220,60 225,30 230,75 235,60 260,60 280,60"/>
            <text x="8" y="14" style="font:9px 'JetBrains Mono',monospace; fill:var(--muted)">steps</text>
            <text x="140" y="14" style="font:9px 'JetBrains Mono',monospace; fill:var(--muted)">HR &middot; bpm</text>
            <text x="280" y="96" text-anchor="end" style="font:9px 'JetBrains Mono',monospace; fill:var(--accent)">predict &rarr;</text>
          </svg>
        </div>
        <h3 class="proj-title">WellnessPlus Health Tracker</h3>
        <p class="proj-desc">
          Tracks health via day-to-day signals like steps and vitals, surfaces insights
          over time, and analyses reported symptoms to predict likely conditions.
          React front-end with Supabase for auth and row-level-secure persistence.
        </p>
        <div class="proj-foot">
          <div class="proj-stack">
            <span><b>React</b></span>
            <span><b>Supabase</b></span>
            <span><b>Tailwind</b></span>
          </div>
          <span class="proj-links">
            <a class="proj-link" href="https://wellnesspluss.vercel.app/" target="_blank" rel="noopener">live &#8599;</a>
            <a class="proj-link" href="https://github.com/prasadanand412/wellnesspluss" target="_blank" rel="noopener">github &#8599;</a>
          </span>
        </div>
      </article>

      <!-- 04 Blood Bank Management (half) -->
      <article class="proj" data-tags="sys web">
        <div class="proj-head">
          <span class="proj-idx">04 &middot; data systems</span>
          <span class="proj-status">shipped</span>
        </div>
        <div class="proj-figure">
          <!-- ER diagram-ish -->
          <svg viewBox="0 0 300 100" width="100%" height="100%" role="img" aria-label="Entity-relationship diagram connecting donors, requests, inventory and hospitals tables">
            <g fill="none" stroke="var(--rule-strong)" stroke-width="0.8">
              <rect x="20" y="30" width="60" height="40"/>
              <rect x="120" y="10" width="60" height="30"/>
              <rect x="120" y="60" width="60" height="30"/>
              <rect x="220" y="30" width="60" height="40"/>
              <line x1="80" y1="45" x2="120" y2="25"/>
              <line x1="80" y1="55" x2="120" y2="75"/>
              <line x1="180" y1="25" x2="220" y2="45"/>
              <line x1="180" y1="75" x2="220" y2="55"/>
            </g>
            <g style="font:8px 'JetBrains Mono',monospace; fill:var(--muted); text-anchor:middle">
              <text x="50" y="54">donors</text>
              <text x="150" y="28">requests</text>
              <text x="150" y="78">inventory</text>
              <text x="250" y="54">hospitals</text>
            </g>
            <g fill="var(--accent)">
              <circle cx="80" cy="45" r="1.5"/><circle cx="80" cy="55" r="1.5"/>
              <circle cx="120" cy="25" r="1.5"/><circle cx="120" cy="75" r="1.5"/>
              <circle cx="180" cy="25" r="1.5"/><circle cx="180" cy="75" r="1.5"/>
              <circle cx="220" cy="45" r="1.5"/><circle cx="220" cy="55" r="1.5"/>
            </g>
          </svg>
        </div>
        <h3 class="proj-title">Blood Bank Management</h3>
        <p class="proj-desc">
          Python + SQL system for donor registration, inventory tracking, and request routing
          across hospital records. Focus on schema correctness, transactional integrity, and
          a clean admin surface.
        </p>
        <div class="proj-foot">
          <div class="proj-stack">
            <span><b>Python</b></span>
            <span><b>SQL</b></span>
          </div>
          <a class="proj-link" href="https://github.com/prasadanand412/blood-bank-management-system" target="_blank" rel="noopener">github &#8599;</a>
        </div>
      </article>

    </div>
  </div>
</section>

<div class="cli-strip">
  <div class="wrap cli-strip-inner">
    <span><span class="prompt">$</span> <span class="cmd">ping prasadanand412@gmail.com</span></span>
    <span class="sep">|</span>
    <span class="out">reply within 48h &middot; IST</span>
    <span class="sep">|</span>
    <span><span class="prompt">$</span> <span class="cmd">open --linkedin</span></span>
    <span class="out">/in/prasad-anand</span>
  </div>
</div>

<!-- ============ CONTACT ============ -->
<section class="section" id="contact" aria-labelledby="contact-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 05</b> / contact</div>
      <div>
        <h2 class="section-title" id="contact-title">Open a <i>connection</i>.</h2>
        <p class="section-sub">Available for remote collaborations and internships. I read every message.</p>
      </div>
    </div>

    <div class="contact-grid">
      <div></div>
      <div class="contact-info">
        <dl>
          <dt>// email</dt>
          <dd><a href="mailto:prasadanand412@gmail.com">prasadanand412@gmail.com</a></dd>
          <dt>// linkedin</dt>
          <dd><a href="https://www.linkedin.com/in/prasad-anand/" target="_blank" rel="noopener">/in/prasad-anand</a></dd>
          <dt>// github</dt>
          <dd><a href="https://github.com/prasadanand412" target="_blank" rel="noopener">/prasadanand412</a></dd>
          <dt>// leetcode</dt>
          <dd><a href="https://leetcode.com/u/Prasad_Anand/" target="_blank" rel="noopener">/u/Prasad_Anand</a></dd>
          <dt>// codeforces</dt>
          <dd><a href="https://codeforces.com/profile/AArray" target="_blank" rel="noopener">/AArray</a></dd>
          <dt>// location</dt>
          <dd>Pune, Maharashtra &middot; IN &middot; IST</dd>
        </dl>
      </div>
      <form id="contact-form">
        <div class="field">
          <label for="n">01 &middot; full name</label>
          <input id="n" name="name" required placeholder="jane doe"/>
        </div>
        <div class="field">
          <label for="e">02 &middot; email address</label>
          <input id="e" name="email" type="email" required placeholder="jane@company.com"/>
        </div>
        <div class="field">
          <label for="m">03 &middot; message</label>
          <textarea id="m" name="message" required placeholder="what are you working on?"></textarea>
        </div>
        <p class="form-note">This form is not yet wired to a backend &mdash; messages are not sent. Please use the email link above for now.</p>
        <div class="form-actions">
          <small>replies within 48h &middot; IST business hours</small>
          <button type="submit" class="btn primary">send message <span class="arrow" aria-hidden="true">&rarr;</span></button>
        </div>
      </form>
    </div>
  </div>
</section>

</main>

<footer>
  <div class="wrap foot-grid">
    <div class="foot-brand"><span class="dot" style="width:8px;height:8px;background:var(--accent);display:inline-block;" aria-hidden="true"></span> prasad_anand</div>
    <div>&copy; 2026 &middot; built by hand with html &amp; care</div>
    <div class="foot-links">
      <a href="#work">&uarr; top</a>
      <a href="#projects">projects</a>
      <a href="#contact">contact</a>
    </div>
  </div>
</footer>

<script src="/static/app.js"><\/script>

</body>
</html>`;
var Q = new q();
var Ee = Object.assign({ "/src/index.tsx": Z });
var $ = false;
for (let [, e4] of Object.entries(Ee)) e4 && (Q.all(`*`, (t3) => {
  let n2;
  try {
    n2 = t3.executionCtx;
  } catch {
  }
  return e4.fetch(t3.req.raw, t3.env, n2);
}), Q.notFound((t3) => {
  let n2;
  try {
    n2 = t3.executionCtx;
  } catch {
  }
  return e4.fetch(t3.req.raw, t3.env, n2);
}), $ = true);
if (!$) throw Error(`Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']`);

// ../node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody = /* @__PURE__ */ __name(async (request, env2, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env2);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e4) {
      console.error("Failed to drain the unused request body.", e4);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;

// ../node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError(e4) {
  return {
    name: e4?.name,
    message: e4?.message ?? String(e4),
    stack: e4?.stack,
    cause: e4?.cause === void 0 ? void 0 : reduceError(e4.cause)
  };
}
__name(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name(async (request, env2, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env2);
  } catch (e4) {
    const error3 = reduceError(e4);
    const body = JSON.stringify(error3);
    const headers = {
      "Content-Type": "application/json",
      "MF-Experimental-Error-Stack": "true"
    };
    const encoded = encodeURIComponent(body);
    if (encoded.length <= 8192) {
      headers["MF-Experimental-Error-Stack-Payload"] = encoded;
    }
    return new Response(body, { status: 500, headers });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;

// ../.wrangler/tmp/bundle-LXT6L0/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = Q;

// ../node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env2, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env2, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env2, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env2, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");

// ../.wrangler/tmp/bundle-LXT6L0/middleware-loader.entry.ts
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  scheduledTime;
  cron;
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env2, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env2, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env2, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env2, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env2, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env2, ctx) => {
      this.env = env2;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default as default
};
//# sourceMappingURL=bundledWorker-0.5915653944459394.mjs.map
