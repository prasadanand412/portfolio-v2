import { Hono } from 'hono'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

app.use('/static/*', serveStatic({ root: './public' }))

app.get('/', (c) => {
  return c.html(PAGE)
})

const PAGE = `<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Prasad Anand — AI/ML Engineer</title>
<meta name="description" content="Prasad Anand — computer engineering student and AI/ML intern in Pune, IN. Applied machine learning, NLP systems, and pragmatic backend engineering." />
<meta property="og:title" content="Prasad Anand — AI/ML Engineer" />
<meta property="og:description" content="Computer engineering student and AI/ML intern in Pune, IN. Applied machine learning, NLP systems, and pragmatic backend engineering." />
<meta property="og:type" content="website" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;1,9..144,400&display=swap" rel="stylesheet">
<link href="/static/style.css" rel="stylesheet" />
</head>
<body>

<!-- ============ TOP BAR ============ -->
<header class="topbar">
  <div class="wrap topbar-inner">
    <div class="brand">
      <span class="dot"></span>
      <span>prasad_anand</span>
      <small>&middot; v2.026</small>
    </div>
    <nav class="nav" aria-label="Primary">
      <a href="#work" class="on">work</a>
      <a href="#about">about</a>
      <a href="#skills">skills</a>
      <a href="#experience">experience</a>
      <a href="#projects">projects</a>
      <a href="#contact">contact</a>
    </nav>
    <div class="top-right">
      <span class="status"><span class="pulse" aria-hidden="true"></span> available &middot; IST</span>
      <button class="theme-toggle" id="themeToggle" type="button" aria-label="Toggle color theme">&mdash; light</button>
    </div>
  </div>
</header>

<main id="main-content">

<!-- ============ HERO ============ -->
<section class="hero" id="work" aria-label="Introduction">
  <div class="wrap">

    <p class="hero-meta">
      <span>portfolio / 2026</span>
      <span>pune, IN</span>
      <span>lat 18.51&deg;N &middot; lon 73.85&deg;E</span>
    </p>

    <div class="hero-grid">
      <div>
        <h1 class="hero-title">
          Prasad <span class="accent">Anand</span>.
        </h1>
        <p class="hero-role">
          <span class="k">ML Intern @ Cubeage Technologies Pvt. Ltd.</span> &mdash; building applied ML pipelines
          and <span class="k">NLP systems</span>. Currently developing
          <span class="k">DocuSense</span>, a document analyzer that extracts structured meaning from
          contracts, agreements &amp; resumes using local LLMs (Qwen&nbsp;2.5&nbsp;7B) and Gemini.
          Previously ML intern @ Tantrata Digital.
        </p>
        <div class="hero-cta">
          <a href="#projects" class="btn primary">view projects <span class="arrow" aria-hidden="true">&rarr;</span></a>
          <a href="#contact" class="btn">get in touch</a>
        </div>
      </div>

      <!-- Notebook cell block -->
      <div class="notebook" role="img" aria-label="Notebook cell demonstrating Prasad's engineer bio, a training loss curve, and a live command prompt">
        <div class="cell md">
          <div class="cell-gutter">md</div>
          <div class="cell-body"># prasad_bio.ipynb &middot; cell 01</div>
        </div>
        <div class="cell">
          <div class="cell-gutter"><span class="marker">In [1]:</span></div>
          <div class="cell-body code"><span class="tok-kw">from</span> prasad <span class="tok-kw">import</span> Engineer

me = Engineer(
    role=<span class="tok-str">"ML Intern"</span>,
    org=<span class="tok-str">"Cubeage Technologies"</span>,
    stack=[<span class="tok-str">"python"</span>, <span class="tok-str">"pytorch"</span>, <span class="tok-str">"nlp"</span>],
    building=<span class="tok-str">"docusense &middot; nlp pipelines"</span>,
)
me.<span class="tok-fn">summary</span>()<span class="caret" aria-hidden="true"></span></div>
        </div>
        <div class="cell out">
          <div class="cell-gutter">Out[1]:</div>
          <div class="cell-body">
            <div><span class="tok-comment"># training curve &middot; docusense classifier v2</span></div>
            <svg class="mini-chart" viewBox="0 0 300 60" preserveAspectRatio="none" aria-hidden="true">
              <defs>
                <pattern id="ga" width="30" height="15" patternUnits="userSpaceOnUse">
                  <path d="M30 0 L0 0 0 15" fill="none" stroke="currentColor" stroke-width="0.3" opacity="0.25"/>
                </pattern>
              </defs>
              <rect width="300" height="60" fill="url(#ga)"/>
              <polyline fill="none" stroke="var(--muted)" stroke-width="1"
                points="0,10 40,14 80,20 120,28 160,36 200,44 240,50 280,54 300,55" opacity="0.6"/>
              <polyline fill="none" stroke="var(--accent)" stroke-width="1.4"
                points="0,55 40,42 80,32 120,26 160,20 200,16 240,13 280,11 300,10"/>
              <circle cx="300" cy="10" r="2.2" fill="var(--accent)"/>
            </svg>
            <div style="display:flex; justify-content:space-between; font-size:10.5px; margin-top:4px;">
              <span>epoch 0</span><span>loss &darr; 0.021</span><span>epoch 50</span>
            </div>
          </div>
        </div>
        <div class="cell">
          <div class="cell-gutter"><span class="marker">In [2]:</span></div>
          <div class="cell-body code" id="live-cell" aria-hidden="true"></div>
        </div>
      </div>
    </div>

    <dl class="coords">
      <div><dt>current focus</dt><dd>NLP &middot; document AI &middot; LLM pipelines</dd></div>
      <div><dt>internships</dt><dd>02 completed &middot; 01 active</dd></div>
      <div><dt>open to</dt><dd>Remote &middot; Collab &middot; Research</dd></div>
      <div><dt>last commit</dt><dd id="last-commit">&mdash;</dd></div>
    </dl>

  </div>
</section>

<!-- ============ ABOUT ============ -->
<section class="section" id="about" aria-labelledby="about-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 01</b> / about</div>
      <div>
        <h2 class="section-title" id="about-title">A short <i>readme</i>.</h2>
        <p class="section-sub">Where I come from, what I work on, and what I'm optimising for.</p>
      </div>
    </div>

    <div class="about-body">
      <div></div>
      <div class="about-prose">
        <p class="lead">
          I'm a computer engineering student and software intern based in Pune, working at the
          intersection of <em>applied machine learning</em> and pragmatic backend systems.
        </p>
        <p>
          My work sits between two disciplines. On one side, training and evaluating models &mdash;
          currently focused on sequence models (LSTM, small transformers) for financial and
          health-signal data. On the other, the unglamorous plumbing that makes them useful:
          ETL, schema design in PostgreSQL, deployment on Vercel/Supabase.
        </p>
        <p>
          I write C++ when the problem calls for it &mdash; graph algorithms, competitive programming,
          anything where the constant factor matters. Python is where I <em>think</em>; C++ is
          where I <em>measure</em>.
        </p>
      </div>

      <!-- Confusion matrix figure -->
      <figure class="about-figure" style="margin:0;">
        <svg viewBox="0 0 240 200" width="100%" role="img" aria-labelledby="cm-title cm-desc">
          <title id="cm-title">Confusion matrix, 4-class classifier</title>
          <desc id="cm-desc">A 4x4 confusion matrix heatmap with diagonal accuracy values 0.85, 0.78, 0.72 and 0.90.</desc>
          <style>
            .cm-t { font: 10px 'JetBrains Mono', monospace; fill: var(--muted); }
            .cm-h { font: 9px 'JetBrains Mono', monospace; fill: var(--muted-2); letter-spacing: 0.05em; }
          </style>
          <text class="cm-h" x="120" y="14" text-anchor="middle">predicted &rarr;</text>
          <text class="cm-h" x="10" y="110" text-anchor="middle" transform="rotate(-90 10 110)">actual &rarr;</text>

          <!-- axis labels -->
          <text class="cm-t" x="50" y="30" text-anchor="middle">A</text>
          <text class="cm-t" x="110" y="30" text-anchor="middle">B</text>
          <text class="cm-t" x="170" y="30" text-anchor="middle">C</text>
          <text class="cm-t" x="230" y="30" text-anchor="middle">D</text>
          <text class="cm-t" x="26" y="64" text-anchor="middle">A</text>
          <text class="cm-t" x="26" y="104" text-anchor="middle">B</text>
          <text class="cm-t" x="26" y="144" text-anchor="middle">C</text>
          <text class="cm-t" x="26" y="184" text-anchor="middle">D</text>

          <!-- 4x4 grid -->
          <g transform="translate(40,40)">
            <!-- row 1 -->
            <rect x="0"   y="0"  width="40" height="40" fill="var(--accent)" opacity="0.85"/>
            <rect x="40"  y="0"  width="40" height="40" fill="var(--accent)" opacity="0.1"/>
            <rect x="80"  y="0"  width="40" height="40" fill="var(--accent)" opacity="0.05"/>
            <rect x="120" y="0"  width="40" height="40" fill="var(--accent)" opacity="0.12"/>
            <!-- row 2 -->
            <rect x="0"   y="40" width="40" height="40" fill="var(--accent)" opacity="0.08"/>
            <rect x="40"  y="40" width="40" height="40" fill="var(--accent)" opacity="0.78"/>
            <rect x="80"  y="40" width="40" height="40" fill="var(--accent)" opacity="0.15"/>
            <rect x="120" y="40" width="40" height="40" fill="var(--accent)" opacity="0.03"/>
            <!-- row 3 -->
            <rect x="0"   y="80" width="40" height="40" fill="var(--accent)" opacity="0.05"/>
            <rect x="40"  y="80" width="40" height="40" fill="var(--accent)" opacity="0.18"/>
            <rect x="80"  y="80" width="40" height="40" fill="var(--accent)" opacity="0.72"/>
            <rect x="120" y="80" width="40" height="40" fill="var(--accent)" opacity="0.09"/>
            <!-- row 4 -->
            <rect x="0"   y="120" width="40" height="40" fill="var(--accent)" opacity="0.02"/>
            <rect x="40"  y="120" width="40" height="40" fill="var(--accent)" opacity="0.06"/>
            <rect x="80"  y="120" width="40" height="40" fill="var(--accent)" opacity="0.14"/>
            <rect x="120" y="120" width="40" height="40" fill="var(--accent)" opacity="0.9"/>
            <!-- grid lines -->
            <g stroke="var(--bg)" stroke-width="1" fill="none">
              <line x1="40" y1="0" x2="40" y2="160"/>
              <line x1="80" y1="0" x2="80" y2="160"/>
              <line x1="120" y1="0" x2="120" y2="160"/>
              <line x1="0" y1="40" x2="160" y2="40"/>
              <line x1="0" y1="80" x2="160" y2="80"/>
              <line x1="0" y1="120" x2="160" y2="120"/>
            </g>
            <!-- numbers -->
            <g style="font: 10px 'JetBrains Mono', monospace; fill: var(--bg); text-anchor: middle;">
              <text x="20" y="25">0.85</text>
              <text x="60" y="65">0.78</text>
              <text x="100" y="105">0.72</text>
              <text x="140" y="145">0.90</text>
            </g>
          </g>
        </svg>
        <figcaption class="figure-cap">
          <b>fig. 01</b> &mdash; confusion matrix, 4-class classifier &middot; val_acc = 0.81
        </figcaption>
      </figure>
    </div>
  </div>
</section>

<div class="cli-strip">
  <div class="wrap cli-strip-inner">
    <span><span class="prompt">$</span> <span class="cmd">cat ~/portfolio/skills.yaml</span></span>
    <span class="sep">|</span>
    <span class="out">21 tools &middot; 4 tiers &middot; sorted by comfort</span>
    <span class="sep">|</span>
    <span><span class="prompt">$</span> <span class="cmd">tier=1 grep .</span></span>
    <span class="out">python, c++, numpy, postgres, git, linux</span>
  </div>
</div>

<!-- ============ SKILLS ============ -->
<section class="section" id="skills" aria-labelledby="skills-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 02</b> / stack</div>
      <div>
        <h2 class="section-title" id="skills-title">Working <i>toolkit</i>.</h2>
        <p class="section-sub">Ordered by comfort and time-under-the-hood, not by hype. Row 1 is where I ship daily.</p>
      </div>
    </div>

    <div class="skills-row">
      <div class="skills-row-label"><span class="num">01</span> &middot; daily driver</div>
      <div class="skills-cloud">
        <span class="chip t1">Python <span class="lvl">// primary</span></span>
        <span class="chip t1">C / C++ <span class="lvl">// perf</span></span>
        <span class="chip t1">NumPy</span>
        <span class="chip t1">PostgreSQL</span>
        <span class="chip t1">Git</span>
        <span class="chip t1">Linux shell</span>
      </div>
    </div>

    <div class="skills-row">
      <div class="skills-row-label"><span class="num">02</span> &middot; comfortable</div>
      <div class="skills-cloud">
        <span class="chip t2">PyTorch</span>
        <span class="chip t2">TensorFlow / Keras</span>
        <span class="chip t2">scikit-learn</span>
        <span class="chip t2">Matplotlib</span>
        <span class="chip t2">Pandas</span>
        <span class="chip t2">JavaScript &middot; ES2022</span>
        <span class="chip t2">React</span>
        <span class="chip t2">Tailwind</span>
        <span class="chip t2">Supabase</span>
      </div>
    </div>

    <div class="skills-row">
      <div class="skills-row-label"><span class="num">03</span> &middot; exploring</div>
      <div class="skills-cloud">
        <span class="chip t3">NLP &middot; spaCy &middot; Transformers</span>
        <span class="chip t3">Local LLMs &middot; Ollama &middot; Qwen 2.5</span>
        <span class="chip t3">Gemini API</span>
        <span class="chip t3">CUDA basics</span>
        <span class="chip t3">Docker</span>
        <span class="chip t3">FastAPI</span>
        <span class="chip t3">Vercel edge</span>
        <span class="chip t3">DuckDB</span>
        <span class="chip t3">Rust</span>
      </div>
    </div>

    <div class="skills-row">
      <div class="skills-row-label"><span class="num">04</span> &middot; foundations</div>
      <div class="skills-cloud">
        <span class="chip t3">Data structures &amp; algorithms</span>
        <span class="chip t3">Graph algorithms</span>
        <span class="chip t3">Linear algebra</span>
        <span class="chip t3">Probability &amp; statistics</span>
        <span class="chip t3">Competitive programming</span>
        <span class="chip t3">System design (intro)</span>
      </div>
    </div>
  </div>
</section>

<div class="cli-strip">
  <div class="wrap cli-strip-inner">
    <span><span class="prompt">$</span> <span class="cmd">git log --oneline --since="2024-01" ./career</span></span>
    <span class="sep">|</span>
    <span class="out">3 commits &middot; head @ cubeage</span>
    <span class="sep">|</span>
    <span><span class="prompt">$</span> <span class="cmd">whoami</span></span>
    <span class="out">ml_intern &middot; building docusense</span>
  </div>
</div>

<!-- ============ EXPERIENCE ============ -->
<section class="section" id="experience" aria-labelledby="experience-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 03</b> / experience</div>
      <div>
        <h2 class="section-title" id="experience-title">Where I've <i>shipped</i>.</h2>
        <p class="section-sub">Two internships to date, one active. Compact log &mdash; reverse chronological.</p>
      </div>
    </div>

    <div class="xp-table">
      <article class="xp-row">
        <div class="xp-date">JUN 2026 &mdash;<br/>PRESENT</div>
        <div>
          <h3 class="xp-role">ML Intern</h3>
          <div class="xp-company">CUBEAGE TECHNOLOGIES PVT. LTD.</div>
          <p class="xp-desc">
            Building applied ML pipelines and NLP systems. Currently developing
            <em>DocuSense</em>, a document analyzer that reads contracts, rental agreements
            and resumes and extracts key terms, obligations, and ATS-style scoring &mdash;
            powered by local LLMs (Qwen&nbsp;2.5&nbsp;7B via Ollama) and the Gemini API.
          </p>
        </div>
        <div class="xp-tags">
          <span>python</span>
          <span>nlp &middot; transformers</span>
          <span>qwen &middot; gemini</span>
          <span>ollama</span>
        </div>
        <div class="xp-arrow" aria-hidden="true">&rarr;</div>
      </article>

      <article class="xp-row">
        <div class="xp-date">JAN 2026 &mdash;<br/>FEB 2026</div>
        <div>
          <h3 class="xp-role">Software Intern, AI/ML</h3>
          <div class="xp-company">TANTRATA DIGITAL SOLUTIONS PVT. LTD.</div>
          <p class="xp-desc">
            Contributed to specialised software cycles focused on data-driven logic inside
            AI/ML workflows. Built feature-extraction pipelines, model evaluation harnesses,
            and internal tooling in Python.
          </p>
        </div>
        <div class="xp-tags">
          <span>python</span>
          <span>numpy &middot; pandas</span>
          <span>model eval</span>
        </div>
        <div class="xp-arrow" aria-hidden="true">&rarr;</div>
      </article>

      <article class="xp-row">
        <div class="xp-date">JUN 2025 &mdash;<br/>JUL 2025</div>
        <div>
          <h3 class="xp-role">Data Intern</h3>
          <div class="xp-company">GREENFINCH DIGITAL BUSINESS SOLUTIONS PVT. LTD.</div>
          <p class="xp-desc">
            Worked on digital-transformation projects &mdash; data cleaning, business-process
            modelling, and prototype dashboards. Focused summer program.
          </p>
        </div>
        <div class="xp-tags">
          <span>sql</span>
          <span>dashboards</span>
          <span>data modelling</span>
        </div>
        <div class="xp-arrow" aria-hidden="true">&rarr;</div>
      </article>
    </div>
  </div>
</section>

<div class="cli-strip">
  <div class="wrap cli-strip-inner">
    <span><span class="prompt">$</span> <span class="cmd">ls ~/projects</span></span>
    <span class="sep">|</span>
    <span class="out">docusense/&nbsp; oiltrace/&nbsp; wellnesspluss/&nbsp; blood-bank/</span>
    <span class="sep">|</span>
    <span><span class="prompt">$</span> <span class="cmd">wc -l **/*.py</span></span>
    <span class="out">~ 8.4k loc python</span>
  </div>
</div>

<!-- ============ PROJECTS ============ -->
<section class="section" id="projects" aria-labelledby="projects-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 04</b> / selected work</div>
      <div style="display:flex; justify-content:space-between; align-items:baseline; gap:24px; flex-wrap:wrap;">
        <div>
          <h2 class="section-title" id="projects-title">Selected <i>works</i>.</h2>
          <p class="section-sub">A short set of projects that show how I think &mdash; across ML, systems, and web.</p>
        </div>
        <div class="proj-filter" role="tablist" aria-label="Filter projects">
          <button class="filter-btn on" data-filter="all" role="tab" aria-selected="true">all &middot; 04</button>
          <button class="filter-btn" data-filter="ml" role="tab" aria-selected="false">ml / nlp</button>
          <button class="filter-btn" data-filter="sys" role="tab" aria-selected="false">systems</button>
          <button class="filter-btn" data-filter="web" role="tab" aria-selected="false">web</button>
        </div>
      </div>
    </div>

    <div class="proj-grid">

      <!-- 01 DocuSense (wide feature) -->
      <article class="proj wide" data-tags="ml">
        <div class="proj-head">
          <span class="proj-idx">01 &middot; nlp &middot; document AI</span>
          <span class="proj-status live">shipped</span>
        </div>
        <div class="proj-figure">
          <!-- Document -> tokens -> extracted fields diagram -->
          <svg viewBox="0 0 400 150" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Diagram: a rental agreement document is processed by Qwen 2.5 7B into tokenized fields, then converted to structured JSON output with tenant, rent, term, notice, risks and score keys">
            <!-- document page -->
            <g fill="none" stroke="var(--rule-strong)" stroke-width="0.8">
              <rect x="20" y="20" width="90" height="110"/>
            </g>
            <g stroke="var(--muted-2)" stroke-width="1" opacity="0.55">
              <line x1="30" y1="34" x2="92" y2="34"/>
              <line x1="30" y1="44" x2="85" y2="44"/>
              <line x1="30" y1="54" x2="100" y2="54"/>
            </g>
            <g stroke="var(--accent)" stroke-width="1.2">
              <line x1="30" y1="68" x2="70" y2="68"/>
              <line x1="30" y1="84" x2="88" y2="84"/>
            </g>
            <g stroke="var(--muted-2)" stroke-width="1" opacity="0.55">
              <line x1="30" y1="96" x2="98" y2="96"/>
              <line x1="30" y1="106" x2="80" y2="106"/>
              <line x1="30" y1="116" x2="92" y2="116"/>
            </g>
            <text x="20" y="14" style="font:9px 'JetBrains Mono',monospace; fill:var(--muted); letter-spacing:0.05em">rental_agreement.pdf</text>

            <!-- arrow -->
            <g stroke="var(--rule-strong)" stroke-width="0.8" fill="none">
              <line x1="115" y1="75" x2="165" y2="75" stroke-dasharray="3 3"/>
              <path d="M162 71 L168 75 L162 79" stroke="var(--accent)"/>
            </g>
            <text x="140" y="70" text-anchor="middle" style="font:8.5px 'JetBrains Mono',monospace; fill:var(--accent)">qwen2.5 7b</text>

            <!-- token stream -->
            <g style="font:9px 'JetBrains Mono',monospace; fill:var(--ink-strong)">
              <rect x="175" y="30"  width="70" height="14" fill="none" stroke="var(--rule-strong)" stroke-width="0.6"/>
              <text x="179" y="40">tenant</text>
              <rect x="175" y="50"  width="70" height="14" fill="none" stroke="var(--rule-strong)" stroke-width="0.6"/>
              <text x="179" y="60">rent &middot; term</text>
              <rect x="175" y="70"  width="70" height="14" fill="var(--accent)" opacity="0.9"/>
              <text x="179" y="80" fill="var(--bg)">clauses &middot; 12</text>
              <rect x="175" y="90"  width="70" height="14" fill="none" stroke="var(--rule-strong)" stroke-width="0.6"/>
              <text x="179" y="100">notice period</text>
              <rect x="175" y="110" width="70" height="14" fill="none" stroke="var(--rule-strong)" stroke-width="0.6"/>
              <text x="179" y="120">obligations</text>
            </g>

            <!-- second arrow -->
            <g stroke="var(--rule-strong)" stroke-width="0.8" fill="none">
              <line x1="250" y1="75" x2="290" y2="75" stroke-dasharray="3 3"/>
              <path d="M287 71 L293 75 L287 79" stroke="var(--accent)"/>
            </g>

            <!-- json output -->
            <g fill="none" stroke="var(--rule)" stroke-width="0.8">
              <rect x="298" y="25" width="92" height="105"/>
            </g>
            <g style="font:9.5px 'JetBrains Mono',monospace; fill:var(--muted)">
              <text x="304" y="40">&#123;</text>
              <text x="310" y="52"><tspan fill="var(--accent)">"tenant"</tspan>: "...",</text>
              <text x="310" y="64"><tspan fill="var(--accent)">"rent"</tspan>: 24000,</text>
              <text x="310" y="76"><tspan fill="var(--accent)">"term"</tspan>: "11m",</text>
              <text x="310" y="88"><tspan fill="var(--accent)">"notice"</tspan>: 30,</text>
              <text x="310" y="100"><tspan fill="var(--accent)">"risks"</tspan>: [2],</text>
              <text x="310" y="112"><tspan fill="var(--accent)">"score"</tspan>: 0.94</text>
              <text x="304" y="124">&#125;</text>
            </g>
            <text x="390" y="14" text-anchor="end" style="font:9px 'JetBrains Mono',monospace; fill:var(--muted); letter-spacing:0.05em">extracted.json</text>
          </svg>
        </div>
        <h3 class="proj-title">DocuSense &mdash; Document Extractor</h3>
        <p class="proj-desc">
          A document analyzer that reads any long-form document &mdash; land registration, rental
          agreements, resumes &mdash; and returns the important terms, clauses and risks as
          structured data. For resumes it produces an ATS-style score. Runs on <em>local LLMs</em>
          (Qwen 2.5 7B via Ollama) with the Google Gemini API as a fallback. Building this
          currently at Cubeage Technologies.
        </p>
        <div class="proj-foot">
          <div class="proj-stack">
            <span><b>Python</b></span>
            <span><b>Qwen 2.5</b></span>
            <span><b>Gemini</b></span>
            <span><b>Ollama</b></span>
          </div>
          <a class="proj-link" href="https://github.com/prasadanand412/DocuSense-document-extractor" target="_blank" rel="noopener">github &#8599;</a>
        </div>
      </article>

      <!-- 02 OilTrace (narrow) -->
      <article class="proj narrow" data-tags="ml sys">
        <div class="proj-head">
          <span class="proj-idx">02 &middot; sat imagery &middot; SIH</span>
          <span class="proj-status">in development</span>
        </div>
        <div class="proj-figure">
          <!-- satellite tile + oil spill + backtrace arrow -->
          <svg viewBox="0 0 140 100" width="100%" height="100%" role="img" aria-label="Diagram: an oil spill detected on a satellite ocean tile, with a backtrace arrow pointing to a predicted source location, factoring in wind direction">
            <!-- ocean tile grid -->
            <defs>
              <pattern id="sea" width="12" height="12" patternUnits="userSpaceOnUse">
                <rect width="12" height="12" fill="var(--bg)"/>
                <path d="M12 0 L0 0 0 12" fill="none" stroke="var(--rule-strong)" stroke-width="0.25" opacity="0.55"/>
              </pattern>
            </defs>
            <rect x="10" y="10" width="120" height="80" fill="url(#sea)" stroke="var(--rule-strong)" stroke-width="0.6"/>
            <!-- oil spill blob -->
            <path d="M92,42 C102,38 112,44 110,54 C114,62 104,68 96,64 C88,68 82,58 88,52 C84,46 88,42 92,42 Z"
                  fill="var(--accent)" opacity="0.85"/>
            <path d="M92,42 C102,38 112,44 110,54 C114,62 104,68 96,64 C88,68 82,58 88,52 C84,46 88,42 92,42 Z"
                  fill="none" stroke="var(--accent)" stroke-width="0.6" opacity="0.6"/>
            <!-- backtrace arrow -->
            <path d="M96 54 Q75 40 45 30" fill="none" stroke="var(--accent)" stroke-width="1.2" stroke-dasharray="3 2"/>
            <path d="M48 32 L42 28 L46 34 Z" fill="var(--accent)"/>
            <!-- source point (predicted) -->
            <circle cx="42" cy="28" r="3" fill="none" stroke="var(--accent)" stroke-width="1"/>
            <circle cx="42" cy="28" r="1.4" fill="var(--accent)"/>
            <!-- wind vector -->
            <g stroke="var(--muted)" stroke-width="0.5" opacity="0.7">
              <line x1="20" y1="20" x2="32" y2="20"/>
              <line x1="30" y1="18" x2="32" y2="20"/>
              <line x1="30" y1="22" x2="32" y2="20"/>
            </g>
            <text x="14" y="18" style="font:7px 'JetBrains Mono',monospace; fill:var(--muted)">wind</text>
            <text x="42" y="22" text-anchor="middle" style="font:7px 'JetBrains Mono',monospace; fill:var(--accent)">src?</text>
            <text x="100" y="78" text-anchor="middle" style="font:7px 'JetBrains Mono',monospace; fill:var(--accent)">spill</text>
          </svg>
        </div>
        <h3 class="proj-title">OilTrace &mdash; Spill Origin Tracer</h3>
        <p class="proj-desc">
          SIH project. Analyses satellite imagery to detect oil spills, then backtraces
          the drift to the actual source using particle physics and environmental factors:
          wind speed, sea-surface temperature, water flow, tide and current.
        </p>
        <div class="proj-foot">
          <div class="proj-stack">
            <span><b>PyTorch</b></span>
            <span><b>CUDA</b></span>
          </div>
          <a class="proj-link" href="https://github.com/prasadanand412/oiltrace" target="_blank" rel="noopener">github &#8599;</a>
        </div>
      </article>

      <!-- 03 WellnessPlus (half) -->
      <article class="proj" data-tags="web ml">
        <div class="proj-head">
          <span class="proj-idx">03 &middot; full-stack + health signals</span>
          <span class="proj-status live">live</span>
        </div>
        <div class="proj-figure">
          <!-- steps bar + HR baseline + symptom -> prediction -->
          <svg viewBox="0 0 300 100" width="100%" height="100%" preserveAspectRatio="none" role="img" aria-label="Chart: daily step-count bars overlaid with a heart-rate trace, trending toward a symptom-based prediction">
            <defs>
              <pattern id="pg2" width="30" height="20" patternUnits="userSpaceOnUse">
                <path d="M30 0 L0 0 0 20" fill="none" stroke="currentColor" stroke-width="0.3" opacity="0.18"/>
              </pattern>
            </defs>
            <rect width="300" height="100" fill="url(#pg2)"/>
            <!-- steps bars -->
            <g fill="var(--accent)" opacity="0.85">
              <rect x="14"  y="60" width="10" height="30"/>
              <rect x="30"  y="48" width="10" height="42"/>
              <rect x="46"  y="52" width="10" height="38"/>
              <rect x="62"  y="38" width="10" height="52"/>
              <rect x="78"  y="30" width="10" height="60"/>
              <rect x="94"  y="56" width="10" height="34"/>
              <rect x="110" y="42" width="10" height="48"/>
            </g>
            <!-- HR trace overlay -->
            <polyline fill="none" stroke="var(--muted)" stroke-width="1" opacity="0.9"
              points="140,60 160,60 165,25 170,80 175,60 200,60 220,60 225,30 230,75 235,60 260,60 280,60"/>
            <text x="8" y="14" style="font:9px 'JetBrains Mono',monospace; fill:var(--muted)">steps</text>
            <text x="140" y="14" style="font:9px 'JetBrains Mono',monospace; fill:var(--muted)">HR &middot; bpm</text>
            <text x="280" y="96" text-anchor="end" style="font:9px 'JetBrains Mono',monospace; fill:var(--accent)">predict &rarr;</text>
          </svg>
        </div>
        <h3 class="proj-title">WellnessPlus Health Tracker</h3>
        <p class="proj-desc">
          Tracks health via day-to-day signals like steps and vitals, surfaces insights
          over time, and analyses reported symptoms to predict likely conditions.
          React front-end with Supabase for auth and row-level-secure persistence.
        </p>
        <div class="proj-foot">
          <div class="proj-stack">
            <span><b>React</b></span>
            <span><b>Supabase</b></span>
            <span><b>Tailwind</b></span>
          </div>
          <span class="proj-links">
            <a class="proj-link" href="https://wellnesspluss.vercel.app/" target="_blank" rel="noopener">live &#8599;</a>
            <a class="proj-link" href="https://github.com/prasadanand412/wellnesspluss" target="_blank" rel="noopener">github &#8599;</a>
          </span>
        </div>
      </article>

      <!-- 04 Blood Bank Management (half) -->
      <article class="proj" data-tags="sys web">
        <div class="proj-head">
          <span class="proj-idx">04 &middot; data systems</span>
          <span class="proj-status">shipped</span>
        </div>
        <div class="proj-figure">
          <!-- ER diagram-ish -->
          <svg viewBox="0 0 300 100" width="100%" height="100%" role="img" aria-label="Entity-relationship diagram connecting donors, requests, inventory and hospitals tables">
            <g fill="none" stroke="var(--rule-strong)" stroke-width="0.8">
              <rect x="20" y="30" width="60" height="40"/>
              <rect x="120" y="10" width="60" height="30"/>
              <rect x="120" y="60" width="60" height="30"/>
              <rect x="220" y="30" width="60" height="40"/>
              <line x1="80" y1="45" x2="120" y2="25"/>
              <line x1="80" y1="55" x2="120" y2="75"/>
              <line x1="180" y1="25" x2="220" y2="45"/>
              <line x1="180" y1="75" x2="220" y2="55"/>
            </g>
            <g style="font:8px 'JetBrains Mono',monospace; fill:var(--muted); text-anchor:middle">
              <text x="50" y="54">donors</text>
              <text x="150" y="28">requests</text>
              <text x="150" y="78">inventory</text>
              <text x="250" y="54">hospitals</text>
            </g>
            <g fill="var(--accent)">
              <circle cx="80" cy="45" r="1.5"/><circle cx="80" cy="55" r="1.5"/>
              <circle cx="120" cy="25" r="1.5"/><circle cx="120" cy="75" r="1.5"/>
              <circle cx="180" cy="25" r="1.5"/><circle cx="180" cy="75" r="1.5"/>
              <circle cx="220" cy="45" r="1.5"/><circle cx="220" cy="55" r="1.5"/>
            </g>
          </svg>
        </div>
        <h3 class="proj-title">Blood Bank Management</h3>
        <p class="proj-desc">
          Python + SQL system for donor registration, inventory tracking, and request routing
          across hospital records. Focus on schema correctness, transactional integrity, and
          a clean admin surface.
        </p>
        <div class="proj-foot">
          <div class="proj-stack">
            <span><b>Python</b></span>
            <span><b>SQL</b></span>
          </div>
          <a class="proj-link" href="https://github.com/prasadanand412/blood-bank-management-system" target="_blank" rel="noopener">github &#8599;</a>
        </div>
      </article>

    </div>
  </div>
</section>

<div class="cli-strip">
  <div class="wrap cli-strip-inner">
    <span><span class="prompt">$</span> <span class="cmd">ping prasadanand412@gmail.com</span></span>
    <span class="sep">|</span>
    <span class="out">reply within 48h &middot; IST</span>
    <span class="sep">|</span>
    <span><span class="prompt">$</span> <span class="cmd">open --linkedin</span></span>
    <span class="out">/in/prasad-anand</span>
  </div>
</div>

<!-- ============ CONTACT ============ -->
<section class="section" id="contact" aria-labelledby="contact-title">
  <div class="wrap">
    <div class="section-head">
      <div class="section-tag"><b>&sect; 05</b> / contact</div>
      <div>
        <h2 class="section-title" id="contact-title">Open a <i>connection</i>.</h2>
        <p class="section-sub">Available for remote collaborations and internships. I read every message.</p>
      </div>
    </div>

    <div class="contact-grid">
      <div></div>
      <div class="contact-info">
        <dl>
          <dt>// email</dt>
          <dd><a href="mailto:prasadanand412@gmail.com">prasadanand412@gmail.com</a></dd>
          <dt>// linkedin</dt>
          <dd><a href="https://www.linkedin.com/in/prasad-anand/" target="_blank" rel="noopener">/in/prasad-anand</a></dd>
          <dt>// github</dt>
          <dd><a href="https://github.com/prasadanand412" target="_blank" rel="noopener">/prasadanand412</a></dd>
          <dt>// leetcode</dt>
          <dd><a href="https://leetcode.com/u/Prasad_Anand/" target="_blank" rel="noopener">/u/Prasad_Anand</a></dd>
          <dt>// codeforces</dt>
          <dd><a href="https://codeforces.com/profile/AArray" target="_blank" rel="noopener">/AArray</a></dd>
          <dt>// location</dt>
          <dd>Pune, Maharashtra &middot; IN &middot; IST</dd>
        </dl>
      </div>
      <form id="contact-form">
        <div class="field">
          <label for="n">01 &middot; full name</label>
          <input id="n" name="name" required placeholder="jane doe"/>
        </div>
        <div class="field">
          <label for="e">02 &middot; email address</label>
          <input id="e" name="email" type="email" required placeholder="jane@company.com"/>
        </div>
        <div class="field">
          <label for="m">03 &middot; message</label>
          <textarea id="m" name="message" required placeholder="what are you working on?"></textarea>
        </div>
        <p class="form-note">This form is not yet wired to a backend &mdash; messages are not sent. Please use the email link above for now.</p>
        <div class="form-actions">
          <small>replies within 48h &middot; IST business hours</small>
          <button type="submit" class="btn primary">send message <span class="arrow" aria-hidden="true">&rarr;</span></button>
        </div>
      </form>
    </div>
  </div>
</section>

</main>

<footer>
  <div class="wrap foot-grid">
    <div class="foot-brand"><span class="dot" style="width:8px;height:8px;background:var(--accent);display:inline-block;" aria-hidden="true"></span> prasad_anand</div>
    <div>&copy; 2026 &middot; built by hand with html &amp; care</div>
    <div class="foot-links">
      <a href="#work">&uarr; top</a>
      <a href="#projects">projects</a>
      <a href="#contact">contact</a>
    </div>
  </div>
</footer>

<script src="/static/app.js"></script>

</body>
</html>`

export default app
